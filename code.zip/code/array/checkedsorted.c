#include<stdio.h>
#include<math.h>
int arr[9]={1,2,4,5,6,7,8,9,10};
int min;
int n=8;

int recurse(int index){
    if(index==n){
        if(arr[index] < arr[index-1]){
            return -1;
        }
    }
    else{
        if(arr[index] < arr[index-1]){
            recurse(index-1);
            return 1;

        }
    }

}

void recu(){
    
    min= (recurse(0) < recurse(1))?recurse(0):recurse(1);
    printf("%d",min);
}
void main(){
int a = recurse(8);
printf("%d",a);
}