#include<stdio.h>
void main(){
    int arr[]={4,5,3};
    int n=3;
     //int first0=arr[n-1];
    //first0+=arr[1];
int first0=arr[0];
first0+=arr[1];
first0-=arr[n-1];
int arr1[n];
arr1[0]=first0/2;
//printf("%d",arr[1]);
for(int i=1;i<n;i++){
    arr1[i]=arr[i-1]  - arr1[0];
}
for(int i=0;i<n;i++){
    printf("%d   ",arr1[i]);
}
}