#include<stdio.h>
void main(){
    int arr[]={1,2,3};
    int n =3;
    int count=0;
    for(int i=0;i<n-2;i++){
        for(int j=i+1;j<n-1;j++){
            for(int k=j+1;k<n;k++){
                if(arr[i]+arr[j]>arr[k] && arr[i]+arr[k]>arr[j] && arr[j]+arr[k]>arr[i]){
                    count++;
                }
            }
        }
    }

    printf("%d",count);
}