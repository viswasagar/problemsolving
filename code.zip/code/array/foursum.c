#include<stdio.h>
void main(){
    int arr[]={10,20,30,20,10,30,10};
    int target=50;
    int n=7;
    for(int i=0;i<n-3;i++){
        for(int j=i+1;j<n-2;j++){
            for(int k=j+1;k<n-1;k++){
                for(int l=k+1;l<n;l++){

                      if(arr[i]+arr[j] +arr[k] + arr[l]== target){
                printf("%d %d  %d  %d       ",i,j,k,l);
            }
                }
              

            }
          
        }
    }
}