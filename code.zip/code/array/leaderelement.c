#include<stdio.h>

void main(){
int arr[9]={16,18,9,4,3,5,1,2,4};
int flag;
for(int i=0;i<8;i++){
     flag=1;
    for(int j=i+1;j<9;j++){
        if(arr[i]<arr[j])
{
    flag=0;
}

    }
    if(flag==1){
        printf("%d    ",arr[i]);
    }
}
}