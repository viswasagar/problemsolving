#include<stdio.h>
int stack[9];
int top=-1;
int arr[9]={16,18,9,4,3,5,1,2,4};
int pop(){
return stack[top--];
}
int peek(){
    return stack[top];
}
void push(int a){
    while(top!=-1 && peek() < a){
        pop();
    }
    stack[++top]=a;
    return;
}

void main(){
    for(int i =0;i<9;i++){
        push(arr[i]);
    }

    printf("");
    while(top!=-1){
        printf("%d   ",pop());
    }
}