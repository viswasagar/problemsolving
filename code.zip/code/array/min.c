#include<stdio.h>
int min(int a ,int b,int c){
    if(a<b){
        if(a<c){
                return a;
            }
            else{
                return c;
            
        }
    }
else if(b<c){
        return b;
    }
    else{
        return c;
    }
}

void main(){
    printf("%d         ",min(1,0,-2));
    int a=9;
    int b=16;
    int c=8;
    int minq= a<b?a<c?a:c:b<c?b:c;
    printf("%d",minq);
}