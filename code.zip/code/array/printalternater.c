#include<stdio.h>
int arr[9]={1,2,3,4,5,6,7,8,9};
int n=9;
void recurse(int index,int flag){
    if(index==n){
        return;
    }
if(flag ==1){
    printf("%d  ",arr[index]);
    recurse(index+1,0);
}
else{
    recurse(index+1,1);
}

}
void main(){
recurse(0,1);
}