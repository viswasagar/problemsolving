#include<stdio.h>
void main(){
int arr[]={1,2,3,4,5,6,7,8,9,10,11,12};
int n=12;
for(int i=0;i<n;i++){
    int left=1;
    for(int j=i+1;j<n;j++){
        left*=arr[j];
    }
    for(int j=i-1;j>=0;j--){
        left*=arr[j];
    }
    printf("%d  ",left);
}
}