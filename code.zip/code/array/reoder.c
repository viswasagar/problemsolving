#include<stdio.h>
#include<stdio.h>
int arr[]={32,23,44,445,56,76,56,45,76,88,99,9};
int reoder[]={3,5,6,7,8,4,1,2,0,9,10,11};
int newarr[12][12];
void init(){
    for(int i=0;i<12;i++){
    newarr[i][0]=arr[i];
        newarr[i][1]=reoder[i];
}
}
void pivott(int left,int right){
    if(right-left<=0){
        return;
    }
    int pivot = newarr[(left+right)/2][1];
    int i=left,j=right;
    while(i<=j){
        while(newarr[i][1] < pivot){
            i++;
        }
        while(newarr[j][1] > pivot){
            j--;
        }
        if(i<=j){
            int temp = newarr[i][0];
            int temp1=newarr[i][1];
            newarr[i][0]=newarr[j][0];
            newarr[i][1]=newarr[j][1];
            newarr[j][0]=temp;
            newarr[j][1]=temp1;
            i++;
            j--;
        }
    }

    pivott(left,i-1);
    pivott(i,right);
}

void main(){
init();
for(int i=0;i<12;i++){
    printf("%d",newarr[i][0]);
        printf("%d",newarr[i][1]);
}
printf("\n");
pivott(0,11);

printf("\n");
for(int i=0;i<12;i++){
    printf("%d  ",newarr[i][0]);
        printf("%d   ",newarr[i][1]);
}
}