#include<stdio.h>
int max1(int a,int b){
    if(a>b){
        return a;
    }
    return b;
}
void main(){
int arr[]={10,8,5,8,-2,1,10,1};
int max=0,maxr=0;
max=arr[7];
for(int i=6;i>=0;i--){
    max=max1(maxr,max);
    int temp=maxr;
    maxr=max;
    max=temp;
    max=max+arr[i];
}
printf("%d %d",max,maxr);
printf("\n %d",max1(max,maxr));
}