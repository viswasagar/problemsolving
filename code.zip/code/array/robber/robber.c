#include<stdio.h>
int max1(int a,int b){
    if(a>b){
        return a;
    }
    return b;
}
void main(){
    int rob[]={10,8,-4,-2,1,2,4};
    int max=0,maxreached=0;
    for(int i=6;i>=0;i--){
        max=max1(max,maxreached+rob[i]);
        if(i!=0){int temp=maxreached;
        maxreached=max;
        max=maxreached;
    }
}
    printf("%d",max);
}