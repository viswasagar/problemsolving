#include<stdio.h>
int max1(int a,int b){
    if(a>b){
        return a;
    }
    return b;
}
void main(){
int rob[]={10,8,-5,-4,-2,1,2,4};
int max=0,maxr=0;
for(int i=7;i>=1;i--){
    max = max1(max,maxr+rob[i]);
    int tempmaxreached=maxr;
    maxr=max;
    max=tempmaxreached+rob[i-1];
}
printf("%d",max);
}