#include<stdio.h>
void main(){
    int arr[]={0, 1, 2, 4, 5, 6, 7, 10,11};
    int index,mid,left,right;
    if(arr[0]!=0){
        printf("0");
    }
left=0,right=8;
    while(left<right){
        mid=left+right;
        if(arr[mid]<mid || arr[mid] > mid){
            right=mid-1;

        }
        else{
            left=mid+1;
        }
    }
printf("%d",left);
}