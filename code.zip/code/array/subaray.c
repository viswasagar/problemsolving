#include<stdio.h>
void main(){
    int arr[]={15,2,4,8,9,10,23};
    int i,j;
    int n=7;
    int sum=0;
    int target=19;
    i=0;
    while(i!=n-1){

        sum=0;
        sum+=arr[i];
        j=i+1;
        while(j!=n-1 ){
            if(sum > target){
                sum-=arr[i];
                i++;
            }
            else if(sum < target){
                sum+=arr[j];
                j++;
            }
            else{
                printf("%d %d",i,j);
                sum-=arr[i];
                i++;
                j++;
            }
        }
    }
}