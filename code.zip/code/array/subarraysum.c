#include<stdio.h>
void main(){
    int arr[]={15,2,4,8,9,10,23};
    int i,j;
    int sum=0;
    int target=19;
int n =7;
    for(i=0;i<n-1;i++){
        sum=0;
        sum+=arr[i];
for(j=i+1;j<n;){
if(sum <target){
    sum+=arr[j];
    j++;
}
else if(sum > target){
    sum=0;
    i++;
    j=i+1;
    
}
else{
    printf("%d %d",i,j);
    printf("%d",sum);
    sum=0;
    i++;
    j=i+1;
}
}
    }
}