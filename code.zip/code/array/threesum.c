#include<stdio.h>
void main(){
    int arr[]={10,20,30,20,10,30};
    int target=50;
    int n=6;
    for(int i=0;i<n-2;i++){
        for(int j=i+1;j<n-1;j++){
            for(int k=j+1;k<n;k++){
                if(arr[i]+arr[j] +arr[k]== target){
                printf("%d %d  %d         ",i,j,k);
            }

            }
          
        }
    }
}