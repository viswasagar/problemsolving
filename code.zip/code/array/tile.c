#include <stdio.h>

#define N 4

int visited[N][N];
int misi = 3, misj = 3; // You can change to any missing square
int tile = 1;

// 4 L-tromino orientations
int dx[4][3] = {
    {0, 1, 0},    // ┌
    {0, 1, 1},    // ┐
    {0, -1, 0},   // └
    {0, -1, -1}   // ┘
};

int dy[4][3] = {
    {0, 0, 1},
    {0, 0, -1},
    {0, 0, 1},
    {0, 0, -1}
};

// Check if we can place L-tromino of type t at (i,j)
int issafe(int i, int j, int t) {
    for (int k = 0; k < 3; k++) {
        int ni = i + dx[t][k];
        int nj = j + dy[t][k];
        if (ni < 0 || ni >= N || nj < 0 || nj >= N) return 0;
        if (visited[ni][nj] != 0) return 0;
    }
    return 1;
}

// Place or remove L-tromino of type t at (i,j)
void place(int i, int j, int t, int id) {
    for (int k = 0; k < 3; k++) {
        int ni = i + dx[t][k];
        int nj = j + dy[t][k];
        visited[ni][nj] = id;
    }
}

// Backtracking function
int backtrack(int remaining) {
    if (remaining == 0) return 1;

    int i, j;
    for (i = 0; i < N; i++) {
        for (j = 0; j < N; j++) {
            if (visited[i][j] == 0) goto found;
        }
    }
    return 0;

found:
    for (int t = 0; t < 4; t++) {
        if (issafe(i, j, t)) {
            place(i, j, t, tile++);
            if (backtrack(remaining - 3)) return 1;
            tile--;
            place(i, j, t, 0);
        }
    }
    return 0;
}

int main() {
    // Initialize board
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            visited[i][j] = 0;

    visited[misi][misj] = -1; // mark missing square

    if (backtrack(N * N - 1)) {
        printf("Tiling possible!\n");
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++)
                printf("%3d ", visited[i][j]);
            printf("\n");
        }
    } else {
        printf("Tiling not possible.\n");
    }

    return 0;
}
