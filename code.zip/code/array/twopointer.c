#include<stdio.h>
void main(){
    int arr[]={15,2,4,8,9,5,10,23};
    int n=8;
    int i,j;
    int sum=0;
    i=0;
    j=i;
    while(i!=n){
        if(sum < 23){
            if(j!=n){
            sum+=arr[j];
            j++;
            }
            else{
                sum-=arr[i];
                i++;
            }
        }
        else if(sum > 23){
            sum-=arr[i];
            i++;
        }
        else{
            printf("%d %d %d ",sum,i,j);
            sum-=arr[i];
            i++;
        }
    }
}