#include<stdio.h>
void main(){
  //  int arr[]={0,0,1,1,0,0,0,0};
  int arr[]={1,0,1,1,1,0,0};
    int i,j,count0=0,count1=0;
    int dup0,dup1;
    int maxlen=0;
    int len;
    int n=7;
    for(j=0;j<n;j++){
        if(arr[j]==1){
            count1++;
        }
        else{
            count0++;
        }
    }
    i=0;
    if(count0 == count1){
        printf("%d  %d",i,j);
        return;
    }
    dup0=count0,dup1=count1;
    for(;i<n;i++){
        if(count0 == count1 && count0!=0 && count1!=0){
            printf("%d %d %d %d  ",count0,count1,i,j-1);
            return;
        }
        if(arr[i]==0){
            count0--;
        }
        else{
            count1--;
        }

    }
    count0=dup0;
    count1=dup1;
    for(--i;i>=0;i--){
      if(count0 == count1 && count0!=0 && count1!=0){
            printf("%d %d",0,i);
            return;
        }
        if(arr[i]==0){
            count0--;
        }
        else{
            count1--;
        }

    }
}