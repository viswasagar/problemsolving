#include<stdio.h>
void main(){
  //  int arr[]={0,0,1,1,0,0,0,0};
  int arr1[]={0,1,0,1,1,1,1};
  int arr2[]={1,1,1,1,1,0,1};
  int sum1=0,sum2=0;
  
    int i,j,count0=0,count1=0;
    int dup0,dup1;
    int maxlen=0;
    int len;
    int n=7;
    for(j=0;j<n;j++){
        if(arr1[j]==1){
            sum1+=arr1[j];
        }
     if(arr2[j]==1){
            sum2+=arr2[j];
        }
    }
    if(sum1==sum2){
      printf("%d",sum1);
        return; 
    }
    
    dup0=sum1,dup1=sum2;
    for(;i<n;i++){
        if(sum1 ==sum2 && sum1!=0 && sum2!=0){
            printf("%d %d %d %d  ",sum1,sum2,i,j-1);
            return;
        }
        if(arr1[i]==1){
            sum1--;
        }
        if(arr2[i]==1){
            sum2--;
        }
        
    }
    sum1=dup0;
    sum2=dup1;
    for(--i;i>=0;i--){
      if(sum1 == sum2 && sum1!=0 && sum2!=0){
            printf("%d %d",0,i);
            return;
        }
         if(arr1[i]==1){
            sum1--;
        }
        if(arr2[i]==1){
            sum2--;
        }
    }

}