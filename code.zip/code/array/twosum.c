#include<stdio.h>
void main(){
    int arr[]={10,20,30,20,10,30};
    int target=50;
    int n=6;
    for(int i=0;i<n-1;i++){
        for(int j=i+1;j<n;j++){
            if(arr[i]+arr[j] == target){
                printf("%d %d           ",i,j);
            }
        }
    }
}