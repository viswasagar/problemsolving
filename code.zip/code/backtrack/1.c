#include <stdio.h>

#define N 4

int visited[N][N];
int misi = 0;
int misj = 1;
int tile = 1;

/* 4 L-tromino shapes, each covering (0,0) */
int dx[4][3] = {
    {0, 1, 0},
    {0, 1, 0},
    {0, -1, 0},
    {0, -1, 0}
};

int dy[4][3] = {
    {0, 0, 1},
    {0, 0, -1},
    {0, 0, 1},
    {0, 0, -1}
};

int can_place(int x, int y, int t) {
    for (int k = 0; k < 3; k++) {
        int nx = x + dx[t][k];
        int ny = y + dy[t][k];
        if (nx < 0 || nx >= N || ny < 0 || ny >= N)
            return 0;
        if (visited[nx][ny])
            return 0;
    }
    return 1;
}

void place(int x, int y, int t, int id) {
    for (int k = 0; k < 3; k++) {
        int nx = x + dx[t][k];
        int ny = y + dy[t][k];
        visited[nx][ny] = id;
    }
}

int backtrack(int remaining) {
    if (remaining == 0)
        return 1;

    int x = -1, y = -1;

    /* find first empty cell */
    for (int i = 0; i < N && x == -1; i++) {
        for (int j = 0; j < N; j++) {
            if (visited[i][j] == 0) {
                x = i;
                y = j;
                break;
            }
        }
    }

    for (int t = 0; t < 4; t++) {
        if (can_place(x, y, t)) {
            place(x, y, t, tile++);
            if (backtrack(remaining - 3))
                return 1;
            tile--;
            place(x, y, t, 0);
        }
    }

    return 0;
}

int main() {
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            visited[i][j] = 0;

    visited[misi][misj] = -1;

    if (backtrack(N * N - 1)) {
        printf("Tiling possible!\n");
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                printf("%3d ", visited[i][j]);
            }
            printf("\n");
        }
    } else {
        printf("Tiling not possible.\n");
    }

    return 0;
}
