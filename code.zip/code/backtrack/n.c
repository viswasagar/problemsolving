#include <stdio.h>

#define N 4   // board size

int board[N][N];     // board representation (unused but kept for your convention)
int visited[N][N];   // 0 = empty, -1 = missing, >0 = tile id
int misi = 0;        // missing square row
int misj = 1;        // missing square col
int tile = 1;        // tile counter

// Four L-shaped tromino configurations as offsets from anchor (posi,posj)
int shapes[4][3][2] = {
    {{0, 0}, {0, 1}, {1, 0}},   // ┌
    {{0, 0}, {0, 1}, {1, 1}},   // ┐
    {{0, 0}, {1, 0}, {1, 1}},   // └
    {{0, 0}, {1, 0}, {1, -1}}   // ┘
};

// Check if placing tromino of given type at (posi,posj) is safe
int issafe(int posi, int posj, int type) {
    for (int k = 0; k < 3; k++) {
        int ni = posi + shapes[type][k][0];
        int nj = posj + shapes[type][k][1];
        if (ni < 0 || ni >= N || nj < 0 || nj >= N) return 0;
        if (visited[ni][nj] != 0) return 0; // must be empty; -1 (missing) is not placeable
    }
    return 1;
}

// Place or remove a tromino
void place(int posi, int posj, int type, int id) {
    for (int k = 0; k < 3; k++) {
        int ni = posi + shapes[type][k][0];
        int nj = posj + shapes[type][k][1];
        visited[ni][nj] = id;
    }
}

// Find the next empty cell (0). Returns 1 if found and fills *oi,*oj
int find_next_empty(int *oi, int *oj) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            if (visited[i][j] == 0) {
                *oi = i; *oj = j;
                return 1;
            }
        }
    }
    return 0;
}

// Backtracking function (posi,posj are unused for anchoring; kept to match your signature)
int backtrack(int posi, int posj, int remaining) {
    if (remaining == 0) return 1; // success

    int i, j;
    if (!find_next_empty(&i, &j)) return 0; // no empty found but remaining != 0

    for (int type = 0; type < 4; type++) {
        if (issafe(i, j, type)) {
            place(i, j, type, tile++);
            if (backtrack(i, j, remaining - 3)) return 1;
            place(i, j, type, 0); // undo
            tile--;
        }
    }
    return 0; // no placement possible from this anchor
}

int main() {
    // Initialize arrays
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++) {
            visited[i][j] = 0;
            board[i][j] = 0;
        }

    // Mark missing square
    visited[misi][misj] = -1;

    // Start backtracking (remaining empty cells exclude the missing one)
    if (backtrack(0, 0, N * N - 1)) {
        printf("Tiling possible!\n");
        for (int i=0; i<N; i++) {
            for (int j=0; j<N; j++) {
                printf("%3d ", visited[i][j]);
            }
            printf("\n");
        }
    } else {
        printf("Tiling not possible.\n");
    }

    return 0;
}