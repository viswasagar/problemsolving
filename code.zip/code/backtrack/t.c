#include <stdio.h>

#define N 4   // board size (must be 2^k)

int board[N][N];   // 0 = empty, -1 = missing, >0 = tile id
int tileId = 1;    // tile counter

// Define the four L-shaped tromino configurations as offsets
int shapes[4][3][2] = {
    {{0,0}, {0,1}, {1,0}},   // ┌
    {{0,0}, {0,1}, {1,1}},   // ┐
    {{0,0}, {1,0}, {1,1}},   // └
    {{0,0}, {1,0}, {1,-1}}   // ┘
};

// Check if placing tromino of given type at (r,c) is safe
int isValid(int r, int c, int type) {
    for (int k = 0; k < 3; k++) {
        int nr = r + shapes[type][k][0];
        int nc = c + shapes[type][k][1];
        if (nr < 0 || nr >= N || nc < 0 || nc >= N) return 0;
        if (board[nr][nc] != 0) return 0; // must be empty
    }
    return 1;
}

// Place or remove a tromino
void place(int r, int c, int type, int id) {
    for (int k = 0; k < 3; k++) {
        int nr = r + shapes[type][k][0];
        int nc = c + shapes[type][k][1];
        board[nr][nc] = id;
    }
}

// Find next empty cell
int findNextEmpty(int *outR, int *outC) {
    for (int r = 0; r < N; r++) {
        for (int c = 0; c < N; c++) {
            if (board[r][c] == 0) {
                *outR = r;
                *outC = c;
                return 1;
            }
        }
    }
    return 0;
}

// Recursive backtracking
int tileBoard() {
    int r, c;
    if (!findNextEmpty(&r, &c)) return 1; // success, all filled

    for (int type = 0; type < 4; type++) {
        if (isValid(r, c, type)) {
            place(r, c, type, tileId++);
            if (tileBoard()) return 1;
            place(r, c, type, 0); // undo
            tileId--;
        }
    }
    return 0; // backtrack
}

int main() {
    // Initialize board
    for (int i=0; i<N; i++)
        for (int j=0; j<N; j++)
            board[i][j] = 0;

    // Mark missing square
    int misi = 0, misj = 1;
    board[misi][misj] = -1;

    if (tileBoard()) {
        printf("Tiling possible!\n");
        for (int i=0; i<N; i++) {
            for (int j=0; j<N; j++) {
                printf("%3d ", board[i][j]);
            }
            printf("\n");
        }
    } else {
        printf("Tiling not possible.\n");
    }

    return 0;
}