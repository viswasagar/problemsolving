#include <iostream>
#include <vector>
using namespace std;

// Define the four L-shaped configurations
const vector<vector<pair<int, int>>> TROMINO_SHAPES = {
    {{0, 0}, {0, 1}, {1, 0}},  // ┌
    {{0, 0}, {0, 1}, {1, 1}},  // ┐
    {{0, 0}, {1, 0}, {1, 1}},  // └
    {{0, 0}, {1, 0}, {1, -1}}  // ┘
};

bool isValid(vector<vector<int>>& board, int r, int c,
             const vector<pair<int, int>>& shape, int size) {
    for (const auto& offset : shape) {
        int nr = r + offset.first;
        int nc = c + offset.second;
        if (nr < 0 || nr >= size || nc < 0 || nc >= size || board[nr][nc] != 0)
            return false;
    }
    return true;
}

void place(vector<vector<int>>& board, int r, int c,
           const vector<pair<int, int>>& shape, int tileId) {
    for (const auto& offset : shape) {
        board[r + offset.first][c + offset.second] = tileId;
    }
}

void removeL(vector<vector<int>>& board, int r, int c,
             const vector<pair<int, int>>& shape) {
    for (const auto& offset : shape) {
        board[r + offset.first][c + offset.second] = 0;
    }
}

bool findNext0(vector<vector<int>>& board, int size,
               int& outR, int& outC) {
    for (int r = 0; r < size; ++r) {
        for (int c = 0; c < size; ++c) {
            if (board[r][c] == 0) {
                outR = r;
                outC = c;
                return true;
            }
        }
    }
    return false;
}

// Main recursive function to fill
bool tileBoard(vector<vector<int>>& board, int size, int tileId) {
    int r, c;
    if (!findNext0(board, size, r, c)) {
        return true;  // All cells filled successfully
    }

    for (const auto& shape : TROMINO_SHAPES) {
        if (isValid(board, r, c, shape, size)) {
            place(board, r, c, shape, tileId);
            if (tileBoard(board, size, tileId + 1)) {
                return true;  // Found valid solution
            }
            removeL(board, r, c, shape);
        }
    }

    return false;  // No valid placement, backtrack
}

vector<vector<int>> tiling(int n, pair<int, int> missing) {
    vector<vector<int>> board(n, vector<int>(n, 0));
    board[missing.first][missing.second] = -1;

    if (tileBoard(board, n, 1))
        return board;

    return {{-1}};
}

int main() {
    int n = 4;  // Must be 2^k
    pair<int, int> missing = {0, 1};

    vector<vector<int>> grid = tiling(n, missing);

    for (const auto& row : grid) {
        for (int cell : row) {
            cout << cell << " ";
        }
        cout << "\n";
    }

    return 0;
}