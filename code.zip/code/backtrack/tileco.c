#include <stdio.h>

#define N 4   // Board size (must be 2^k)

int visited[N][N];   // Board
int misi = 0;        // Missing square row
int misj = 1;        // Missing square column
int tile = 1;        // Tile number counter

// Function to place a tile
void placeTile(int x, int y, int dx1, int dy1, int dx2, int dy2, int dx3, int dy3) {
    visited[x + dx1][y + dy1] = tile;
    visited[x + dx2][y + dy2] = tile;
    visited[x + dx3][y + dy3] = tile;
    tile++;
}

// Recursive divide-and-conquer function
void tromino(int top, int left, int size, int missing_i, int missing_j) {
    if (size == 2) {
        int t = tile++;
        for (int i = 0; i < 2; i++)
            for (int j = 0; j < 2; j++)
                if (top + i != missing_i || left + j != missing_j)
                    visited[top + i][left + j] = t;
        return;
    }

    int s = size / 2;
    int mid_i = top + s;
    int mid_j = left + s;

    // Determine which quadrant the missing square is in
    int quad = 0;
    if (missing_i < mid_i && missing_j < mid_j) quad = 0;      // top-left
    else if (missing_i < mid_i && missing_j >= mid_j) quad = 1; // top-right
    else if (missing_i >= mid_i && missing_j < mid_j) quad = 2; // bottom-left
    else quad = 3;                                              // bottom-right

    // Place center L-tromino
    if (quad != 0) visited[mid_i - 1][mid_j - 1] = tile;
    if (quad != 1) visited[mid_i - 1][mid_j] = tile;
    if (quad != 2) visited[mid_i][mid_j - 1] = tile;
    if (quad != 3) visited[mid_i][mid_j] = tile;
    tile++;

    // Recurse on 4 quadrants
    // top-left
    tromino(top, left, s,
            (quad == 0) ? missing_i : mid_i - 1,
            (quad == 0) ? missing_j : mid_j - 1);
    // top-right
    tromino(top, left + s, s,
            (quad == 1) ? missing_i : mid_i - 1,
            (quad == 1) ? missing_j : mid_j);
    // bottom-left
    tromino(top + s, left, s,
            (quad == 2) ? missing_i : mid_i,
            (quad == 2) ? missing_j : mid_j - 1);
    // bottom-right
    tromino(top + s, left + s, s,
            (quad == 3) ? missing_i : mid_i,
            (quad == 3) ? missing_j : mid_j);
}

int main() {
    // Initialize board
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            visited[i][j] = 0;

    visited[misi][misj] = -1; // Mark missing square

    // Start tiling
    tromino(0, 0, N, misi, misj);

    // Print board
    printf("Tiling possible!\n");
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++)
            printf("%3d ", visited[i][j]);
        printf("\n");
    }

    return 0;
}
