#include <stdio.h>

#define N 4   // board size

int board[N][N];     // board representation
int visited[N][N];   // track visited cells
int misi = 0;        // missing square row
int misj = 1;        // missing square col
int tile = 1;        // tile counter

// Check if placing tromino of given type at (posi,posj) is safe
int issafe(int posi, int posj, int type) {
    if (type == 0) { // ┌─┐ shape
        return (posi+1 < N && posj+1 < N &&
                !visited[posi][posj] && !visited[posi][posj+1] && !visited[posi+1][posj+1]);
    }
    if (type == 1) { // └─┐ shape
        return (posi+1 < N && posj-1 >= 0 &&
                !visited[posi][posj] && !visited[posi][posj-1] && !visited[posi+1][posj-1]);
    }
    if (type == 2) { // ┌─┘ shape
        return (posi+1 < N && posj+1 < N &&
                !visited[posi][posj] && !visited[posi+1][posj] && !visited[posi+1][posj+1]);
    }
    if (type == 3) { // └─┘ shape
        return (posi-1 >= 0 && posj+1 < N &&
                !visited[posi][posj] && !visited[posi-1][posj] && !visited[posi-1][posj+1]);
    }
    return 0;
}

// Place or remove a tromino
void place(int posi, int posj, int type, int id) {
    if (type == 0) {
        visited[posi][posj] = id;
        visited[posi][posj+1] = id;
        visited[posi+1][posj+1] = id;
    }
    else if (type == 1) {
        visited[posi][posj] = id;
        visited[posi][posj-1] = id;
        visited[posi+1][posj-1] = id;
    }
    else if (type == 2) {
        visited[posi][posj] = id;
        visited[posi+1][posj] = id;
        visited[posi+1][posj+1] = id;
    }
    else if (type == 3) {
        visited[posi][posj] = id;
        visited[posi-1][posj] = id;
        visited[posi-1][posj+1] = id;
    }
}

// Backtracking function
int backtrack(int posi, int posj, int remaining) {
    if (remaining == 0) return 1; // success

    // Move to next row if needed
    if (posj >= N) {
        posi++;
        posj = 0;
    }
    if (posi >= N) return 0;

    // Skip already visited (including missing square)
    if (visited[posi][posj]) {
        return backtrack(posi, posj+1, remaining);
    }

    // Try placing trominoes of different types
    for (int type = 0; type < 4; type++) {
        if (issafe(posi, posj, type)) {
            place(posi, posj, type, tile++);
            if (backtrack(posi, posj+1, remaining-3)) return 1;
            place(posi, posj, type, 0); // undo
            tile--;
        }
    }

    return 0; // no placement possible
}

int main() {
    // Initialize arrays
    for (int i=0; i<N; i++)
        for (int j=0; j<N; j++) {
            visited[i][j] = 0;
            board[i][j] = 0;
        }

    // Mark missing square
    visited[misi][misj] = -1;

    // Start backtracking
    if (backtrack(0, 0, N*N - 1)) {
        printf("Tiling possible!\n");
        for (int i=0; i<N; i++) {
            for (int j=0; j<N; j++) {
                printf("%3d ", visited[i][j]);
            }
            printf("\n");
        }
    } else {
        printf("Tiling not possible.\n");
    }

    return 0;
}