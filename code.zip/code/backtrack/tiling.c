#include<stdio.h>
int n;
n=4;
int misi=0;
int misj=1;


int issafe(int posi,int posj,int type){
    if(type==0){
        if(posi+1 < n && posi+1 >=0 && posj+1 < n && posj+1 >=0 && posi >=0 && posi< n && posj+1 <n && posj+1>=0 ){
            return 1;
        }
        else{
            return 0;
        }
    }
    if(type==1){
        if(posi < n && posi >=0 && posj-1 < n && posj-1 >=0 && posi+1 >=0 && posi+1< n && posj-1 <n && posj-1>=0){
            return 1;
        }
        else{
            return 0;
        }
    }
    if(type==2){
        if(posi+1 < n && posi+1 >=0 && posj < n && posj >=0 && posi+1 >=0 && posi+1< n && posj+1 <n && posj+1>=0){
            return 1;
        }
        else{
            return 0;
        }
    }
    if(type==3){
        if(posi-1 < n && posi-1 >=0 && posj-1 < n && posj-1 >=0 && posi-1 >=0 && posi-1< n && posj <n && posj>=0){
            return 1;
        }
        else{
            return 0;
        }
    }
}

int  backtrack(int posi,int posj,int filled){
    if(filled==0){
        return 1;
    }
    if(posi!=misi && posj!=misj){
if(issafe(posi,posj,0)){
    visited[posi][posj]=1;
    visited[posi][posj+1]=1;
    visited[posi+1][posj+1]=1;
    filled+=3;
if(posi==0&& posj==0){
    backtrack(posi+2,posj,filled);
}
    }
if(posi!=misi && posj!=misj){
    if(issafe(posi,posj,1)){
        visited[posi][posj]=1;
        visited[posi][posj-1]=1;
        visited[posi+1][posj-1]=1;
        filled+=3;
        if(posi==misi && posj==misj-1){
            backtrack(posi,posj+2,filled);
        }
    }
}
if(posi!=misi && posj !=misj){
    issafe(posi,posj,2);
}


if(posi!=misi && posj !=misj){
    issafe(posi,posj,3);
}
}


}
void main(){
backtrack(0,0,4*4-1);
int board[n][n];
int visited[n][n];
int placed[n][n];
}