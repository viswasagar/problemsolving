#include <stdio.h>

#define N 4   // board size

int visited[N][N];   // track visited cells
int misi = 0;        // missing square row
int misj = 1;        // missing square col
int tile = 1;        // tile counter

// Check if placing tromino of given type at (i,j) is safe
int issafe(int i, int j, int type) {
    if (type == 0) { // ┌ shape (corner at top-left)
        return (i+1 < N && j+1 < N &&
                !visited[i][j] && !visited[i+1][j] && !visited[i][j+1]);
    }
    if (type == 1) { // ┐ shape (corner at top-right)
        return (i+1 < N && j-1 >= 0 &&
                !visited[i][j] && !visited[i+1][j] && !visited[i][j-1]);
    }
    if (type == 2) { // └ shape (corner at bottom-left)
        return (i-1 >= 0 && j+1 < N &&
                !visited[i][j] && !visited[i-1][j] && !visited[i][j+1]);
    }
    if (type == 3) { // ┘ shape (corner at bottom-right)
        return (i-1 >= 0 && j-1 >= 0 &&
                !visited[i][j] && !visited[i-1][j] && !visited[i][j-1]);
    }
    return 0;
}

// Place or remove a tromino
void place(int i, int j, int type, int id) {
    if (type == 0) { // ┌
        visited[i][j] = id;
        visited[i+1][j] = id;
        visited[i][j+1] = id;
    }
    else if (type == 1) { // ┐
        visited[i][j] = id;
        visited[i+1][j] = id;
        visited[i][j-1] = id;
    }
    else if (type == 2) { // └
        visited[i][j] = id;
        visited[i-1][j] = id;
        visited[i][j+1] = id;
    }
    else if (type == 3) { // ┘
        visited[i][j] = id;
        visited[i-1][j] = id;
        visited[i][j-1] = id;
    }
}

// Backtracking function
int backtrack(int i, int j, int remaining) {
    if (remaining == 0) return 1; // success

    // Move to next row if needed
    if (j >= N) {
        i++;
        j = 0;
    }
    if (i >= N) return 0;

    // Skip already visited (including missing square)
    if (visited[i][j]) {
        return backtrack(i, j+1, remaining);
    }

    // Try placing trominoes of different types
    for (int type = 0; type < 4; type++) {
        if (issafe(i, j, type)) {
            place(i, j, type, tile++);
            if (backtrack(i, j+1, remaining-3)) return 1;
            place(i, j, type, 0); // undo
            tile--;
        }
    }

    return 0; // no placement possible
}

int main() {
    // Initialize arrays
    for (int i=0; i<N; i++)
        for (int j=0; j<N; j++)
            visited[i][j] = 0;

    // Mark missing square
    visited[misi][misj] = -1;

    // Start backtracking
    if (backtrack(0, 0, N*N - 1)) {
        printf("Tiling possible!\n");
        for (int i=0; i<N; i++) {
            for (int j=0; j<N; j++) {
                printf("%3d ", visited[i][j]);
            }
            printf("\n");
        }
    } else {
        printf("Tiling not possible.\n");
    }

    return 0;
}