#include<stdio.h>
void main(){
    int x=8;
    int y=5;
    int m = y;

    int min=((x-y)&((x-y)>>31));
    int mi= (x-y)>>31;
    m=m+mi; 
    printf("%d",mi);
printf("%d",mi);
}