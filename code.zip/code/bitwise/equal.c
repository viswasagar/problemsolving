#include<stdio.h>
void main(){
    int a=9;
    int b=9;
    if((a&-b)==0){
        printf("Not Equal");
    }
    else{
        printf(" Equal");
    }
    a=8;
    b=-8;
    if((a^b)>>31){
        printf("       Have oppposite signs");
    }
    else{
        printf("             Have Sign same");
    }

    
}