#include<stdio.h>
void main(){
    int x=8;
    int y=88;
    int max= x-((x-y)&((x-y)>>31));
    int ma= y-((y-x)&((y-x)>>31));
    printf("the max is %d ",max);
     printf("the max is %d ",ma);
    int min = y+((x-y)&((x-y)>>31));
    printf("the min is %d ",min);
}