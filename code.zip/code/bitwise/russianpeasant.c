#include<stdio.h>
void main(){
    int a=5;
    int b=8;
int result=0;
    while(b>0)
    {
        if(b&1){
            result+=a;

        }
        a<<=1;
        b>>=1;
    }
    printf("%d",result);
}