#include<stdio.h>
void main(){
    int x=5;
    int y=8;
    x=x^y;
    y=y^x;
    x=x^y;
    printf("%d  %d",x,y);
}