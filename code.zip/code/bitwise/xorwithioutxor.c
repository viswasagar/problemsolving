#include<stdbool.h>
#include<stdio.h>
void main(){
    int x =8;
    int y=4;
    int i;
    bool b1;
    int res=0;
    bool b2;
    for(int i=31;i>=0;i--){
        b1= (x & 1<<i) !=0 ? true : false;
        b2= (y & 1<<i) !=0 ? true : false;
        if(b1!=b2){
            res=res | (1<<i);

        }
    }
    printf("%d",res);
}