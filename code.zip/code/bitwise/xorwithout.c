#include<stdio.h>
void main(){
    int x =8;
    int y=9;
    printf("the xor is  %d",(x+y-((x&y)<<1)));
    printf("the addition of 8 and 9 is  %d",(x^y +((x&y)<<1)));
}