#include<stdio.h>
void main(){
    int i,j,n=5;
    for(i=1;i<=n;i++){
        for(j=0;j<i;j++){
            printf("*");
        }
        if(i!=n){
            for(j=0;j<2*n-1-2*i;j++){
                printf(" ");
            }
        }
        else{
            ;
        }
        if(i!=n){
            for(j=0;j<i;j++){
                printf("*");
            }
        }
        else{
            for(j=0;j<i-1;j++){
                printf("*");
            }
        }
        printf("\n");
    }

    for(i=n-1;i>=1;i--){
        for(j=0;j<i;j++){
            printf("*");
        }
        for(j=0;j<2*n-1-2*i;j++){
            printf(" ");
        }
        for(j=0;j<i;j++){
            printf("*");
        }
        printf("\n");
    }
}