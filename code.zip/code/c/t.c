#include <stdio.h>

void main() {
    int mat[5][5] = {
        {1, 2, 3, 4, 17},
        {5, 6, 7, 8, 18},
        {9, 10, 11, 12, 19},
        {13, 14, 15, 16, 20},
        {21, 22, 23, 24, 25}
    };

    int nrow = 5, ncol = 5;
    int i = 0, j = 0;
    int count = 1;
    int dir = 1;   // direction control

    printf("%d ", mat[i][j]);

    while (count < 25) {

        if (dir == 1) {   // up-right
            while (i - 1 >= 0 && j + 1 < ncol) {
                i--; j++;
                printf("%d ", mat[i][j]);
                count++;
            }
            if (j + 1 < ncol) j++;
            else i++;
        }
        else {           // down-left
            while (i + 1 < nrow && j - 1 >= 0) {
                i++; j--;
                printf("%d ", mat[i][j]);
                count++;
            }
            if (i + 1 < nrow) i++;
            else j++;
        }

        if (count < 25) {
            printf("%d ", mat[i][j]);
            count++;
        }

        dir = !dir;  // switch direction
    }

    printf("\n");
}
