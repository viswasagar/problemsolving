#include <stdio.h>

void main(){
    int mat[5][5] = {
        {1, 2, 3, 4, 17},
        {5, 6, 7, 8, 18},
        {9, 10, 11, 12, 19},
        {13, 14, 15, 16, 20},
        {21, 22, 23, 24, 25}
    };
    int nrow = 5;
    int ncol = 5;
    int i, j;

    i = 0; j = 0;
    printf("%d ", mat[0][0]);

    /* first phase */
    while (!(i == nrow - 1 && j == 0)) {

        if (j + 1 < ncol) {
            j++;
            printf("%d ", mat[i][j]);
        }

        while (i + 1 < nrow && j - 1 >= 0) {
            i++;
            j--;
            printf("%d ", mat[i][j]);
        }

        while (i - 1 >= 0 && j + 1 < ncol) {
            i--;
            j++;
            printf("%d ", mat[i][j]);
        }
    }

    /* second phase */
    while (!(i == nrow - 1 && j == ncol - 1)) {

        if (j + 1 < ncol) {
            j++;
            printf("%d ", mat[i][j]);
        }

        while (i + 1 < nrow && j - 1 >= 0) {
            i++;
            j--;
            printf("%d ", mat[i][j]);
        }

        while (i - 1 >= 0 && j + 1 < ncol) {
            i--;
            j++;
            printf("%d ", mat[i][j]);
        }
    }

    printf("\n");
}
