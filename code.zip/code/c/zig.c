#include<stdio.h>
void main(){
  //  int mat[5][5]={{1, 2, 3, 4,17}, 
        //     {5, 6, 7, 8,18},
          //   {9, 10, 11, 12,19},
           //  {13, 14, 15, 16,20},
           // {21,22,23,24,25}};
  // int mat[4][4]={{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};
  int mat[6][6]={{1,2,3,4,5,6},{7,8,9,10,11,12},{13,14,15,16,17,18},{19,20,21,22,23,24},{25,26,27,28,29,30},{31,32,33,34,35,36}};  
  int nrow=6;
    int ncol=6;
    int i,j;
    i=0;
    j=0;
    
    while(1){
        if(i==nrow-1 && j==0){
            break;
        }
      
        if(j+1 < ncol){
          printf("%d   ",mat[i][++j]);}

        while( i+1 < nrow && j-1 >=0){
               if(i==nrow-1 && j==0){
            break;
        } 
        j-=1;
            printf("%d  ",mat[++i][j]);
        }
       
        if(i+1 < nrow){
            i++;
            printf("%d  ",mat[i][j]);
        }
        while(i-1 >=0 &&  j+1 < ncol){
              if(i==nrow-1 && j==0){
            break;
        }
            printf("%d  ",mat[--i][++j]);
        }
     
        
    }
   // printf("\n%d %d",i,j);
    while(1){
        if(i==nrow-1 && j==ncol-1){
            break;
        }
      if(j+1<ncol){
        printf("%d ",mat[i][++j]);
      }
        while( i+1 < nrow && j-1 >=0){
               if(i==nrow-1 && j==ncol-1){
            break;
        } 
        j-=1;
            printf("%d  ",mat[++i][j]);
        }
        if(j+1==ncol-1){
            printf("%d ",mat[i][++j]);
        }
        if(i+1 < nrow){
            i++;
            printf("%d  ",mat[i][j]);
        }
        while(i-1 >=0 &&  j+1 < ncol){
              if(i==nrow-1 && j==ncol-1){
            break;
        }
            printf("%d  ",mat[--i][++j]);
        }
        if(j+1<ncol){
            printf("%d ",mat[i][++j]);
        }
        if(i+1 < nrow){
            i++;
            printf("%d  ",mat[i][j]);
        }
    }
}