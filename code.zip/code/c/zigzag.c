#include<stdio.h>
void main(){
    int mat[4][4]={{1, 2, 3, 4}, 
             {5, 6, 7, 8},
             {9, 10, 11, 12},
             {13, 14, 15, 16}};
    int nrow=4;
    int ncol=4;
    int i,j;
    i=0;
    j=0;
    
    while(1){
        if(i==nrow-1 && j==ncol-1){
            break;
        }
        printf("%d   ",mat[i][j]);
        if(j+1 < ncol){j+=1;}
        while( i+1 < nrow && j-1 >0){
            printf("%d  ",mat[++i][--j]);
        }
         if(i==nrow-1 && j==ncol-1){
            break;
        }
        if(i+1 < nrow){
            i++;
            printf("%d  ",mat[i][j]);
        }
        while(i-1<nrow && j+1 < ncol){
            printf("%d  ",mat[--i][++j]);
        }
         if(i==nrow-1 && j==ncol-1){
            break;
        } 

        
        
    }
}