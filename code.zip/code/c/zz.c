#include <stdio.h>

void main(){
    int mat[5][5] = {
        {1, 2, 3, 4, 17},
        {5, 6, 7, 8, 18},
        {9, 10, 11, 12, 19},
        {13, 14, 15, 16, 20},
        {21, 22, 23, 24, 25}
    };
    int nrow = 5;
    int ncol = 5;
    int i, j;

    i = 0; j = 0;
    printf("%d ", mat[i][j]);

    /* ---------------- PHASE 1 ----------------
       Diagonals starting from top row
       until bottom-left corner is reached
    */
    while (!(i == nrow - 1 && j == 0)) {

        /* move right */
        if (j + 1 < ncol) {
            j++;
            printf("%d ", mat[i][j]);
        }

        /* move down-left */
        while (i + 1 < nrow && j - 1 >= 0) {
            i++;
            j--;
            printf("%d ", mat[i][j]);
        }

        /* move down if possible (ONLY ONE STEP) */
        if (i + 1 < nrow && j == 0) {
            i++;
            printf("%d ", mat[i][j]);
        }

        /* move up-right */
        while (i - 1 >= 0 && j + 1 < ncol) {
            i--;
            j++;
            printf("%d ", mat[i][j]);
        }
    }

    /* ---------------- PHASE 2 ----------------
       Diagonals starting from last column
       until bottom-right corner is reached
    */
    while (!(i == nrow - 1 && j == ncol - 1)) {

        /* move right if possible */
        if (j + 1 < ncol) {
            j++;
            printf("%d ", mat[i][j]);
        }

        /* move down-left */
        while (i + 1 < nrow && j - 1 >= 0) {
            i++;
            j--;
            printf("%d ", mat[i][j]);
        }

        /* move down if possible (ONLY ONE STEP) */
        if (i + 1 < nrow && j == ncol - 1) {
            i++;
            printf("%d ", mat[i][j]);
        }

        /* move up-right */
        while (i - 1 >= 0 && j + 1 < ncol) {
            i--;
            j++;
            printf("%d ", mat[i][j]);
        }
    }

    printf("\n");
}
