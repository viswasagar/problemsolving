#include <stdio.h>

void main(){
    int mat[5][5] = {
        {1, 2, 3, 4, 17},
        {5, 6, 7, 8, 18},
        {9, 10, 11, 12, 19},
        {13, 14, 15, 16, 20},
        {21, 22, 23, 24, 25}
    };

    int nrow = 5, ncol = 5;
    int i = 0, j = 0;
    int count = 1;
    int total = nrow * ncol;

    printf("%d ", mat[i][j]);

    /* PHASE 1 */
    while (count < total && !(i == nrow - 1 && j == 0)) {

        if (j + 1 < ncol && count < total) {
            j++;
            printf("%d ", mat[i][j]);
            count++;
        }

        while (i + 1 < nrow && j - 1 >= 0 && count < total) {
            i++;
            j--;
            printf("%d ", mat[i][j]);
            count++;
        }

        while (i - 1 >= 0 && j + 1 < ncol && count < total) {
            i--;
            j++;
            printf("%d ", mat[i][j]);
            count++;
        }
    }

    /* PHASE 2 */
    while (count < total && !(i == nrow - 1 && j == ncol - 1)) {

        if (j + 1 < ncol && count < total) {
            j++;
            printf("%d ", mat[i][j]);
            count++;
        }

        while (i + 1 < nrow && j - 1 >= 0 && count < total) {
            i++;
            j--;
            printf("%d ", mat[i][j]);
            count++;
        }

        while (i - 1 >= 0 && j + 1 < ncol && count < total) {
            i--;
            j++;
            printf("%d ", mat[i][j]);
            count++;
        }
    }

    printf("\n");
}
