#include<stdio.h>
int arr[5][5]={{1,2,3,4,5},{6,7,8,9,10},{11,12,13,14,15},{16,17,18,19,20},{21,22,23,24,25}};
int mat1(int posi,int posj,int size){
    if(size==3){
        return det1(posi,posj,size);
    }
    if(size==2){
        return det1(posi,posj,size);
    }
    int mat[5-posi-1][5-posi-1];
    for(int i=posi+1;i<5;i++){
    
    }

}
int det1(int posi,int posj,int size){
    if(size==2){
        return mat[posi][posj]*mat[posi+1][posj+1]-mat[posi+1][posj]*mat[posi][posj+1];
    }
    if(size==3){
        int det=0;
        det=mat[posi][posj]*(mat[posi+1][posj+1]*mat[posi+2][posj+2]-mat[posi+1][posj+2]*mat[posi+2][posj+1]);
    }
}
void main(){
int det=0,sign=1;
for(int i=0;i<5;i++)
{
det+=arr[0][i]*sign*det1(0,i,5);
sign*=-1;
}
}