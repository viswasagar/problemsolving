#include<stdio.h>
#include<math.h>
int split(int a ,int b){
    int len1,len2;
    len1=0;
    len2=0;
    while(a!=0){
        len1++;
        a/=10;
    }
    while(b!=0){
        len2++;
        b/=10;
    }
    if(len1>len2){
     if(len1 &1){
        return (len1+1)/2;

     }
        return len1/2;
    }
    else{
        if(len2&1){
        return (len2+1)/2;

        }
        return len2/2;
    }
}
int leftsplit(int a,int len){
    int left,right;

    right=0;
    int orig=len;
    while(len!=0){
right+=(a%10 )*  (pow(10,(orig-len)));
len--;
a/=10;
    }
    left =a;
return left;
}

int rightsplit(int a,int len){
    int left,right;
    right=0;
    int orig=len;
    while(len!=0){
right+=(a%10 )*  pow(10,(orig-len));
len--;
a/=10;
    }
    return right;

}

int karat(int a,int b){
    if(a <10 || b<10){
        return a*b;

    }
    int maxlen=split(a,b);
    int z2=karat(leftsplit(a,maxlen),leftsplit(b,maxlen));
    int z0=karat(rightsplit(a,maxlen),rightsplit(b,maxlen));
    int z1=karat(leftsplit(a,maxlen)+rightsplit(a,maxlen),leftsplit(b,maxlen)+rightsplit(b,maxlen));
    return ((z2*pow(10,(2*maxlen)))+(((z1-z2-z0)*pow(10,maxlen))+z0));
}
void main(){
    int mul =karat(109393,9889);
printf("%d",mul);
}