#include<stdio.h>
int min;
int arr[10]={10,11,22,1,2,3,4,5,14,15};
int merge(int l,int r,int **leftmin,int **rightmin){
    int mid=l+(l+r)/2;
    **leftmin=arr[l];
    **rightmin=arr[mid];
    for(int i=l+1;i<mid;i++){
        if(arr[i] < **leftmin){
            **leftmin=arr[i];
        }
    }
    for(int i=mid;i<=r;i++){
        if(arr[i]< **rightmin){
            **rightmin=arr[i];
        }
    }
    if(**leftmin < **rightmin){
        if(**leftmin < min){
            min=**leftmin;
        }
    }
     if(**rightmin < **leftmin){
        if(**rightmin < min){
            min=**rightmin;
        }
    }


}
void sort(int left,int right){
if(left<right){
    int mid=left+(right-left)/2;
    int *leftmin1;
    sort(left,mid-1);
    int *rightmin1;
    sort(mid,right);
    merge(left,right,&leftmin1,&rightmin1);

}
}
void main(){
int *min1;
    sort(0,10);
    printf("%d",min);
}