#include<stdio.h>
int arr[10]={14,15,155,16,4,166,18,19,20,22};
int min=9999999;
int merge(int l,int r){
    int mid=l+(r-l)/2;
    int leftmin=arr[l];
    int rightmin=arr[mid];
    for(int i =l+1;i<mid;i++){
        if(arr[i]<leftmin){
            leftmin=arr[i];
        }
    }
    for(int i=mid;i<=r;i++){
        if(arr[i]<rightmin){
            rightmin=arr[i];
        }
    }
    if(leftmin <rightmin){
        if(leftmin < min){
            min=leftmin;
        }
    }
    if(rightmin < leftmin){
        if(rightmin  < min){
            min=rightmin;
        }
    }


}

void div(int l,int r){
    int mid=l+(r-l)/2;
    merge(l,mid);
    merge(mid+1,r);
}

void main(){
    div(0,9);
    printf("%d",min);
}