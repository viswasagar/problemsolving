#include<stdio.h>
int xpow(int x, int n);  
int pow1(int b,int e){
    if(b==1){
        return 1;
    }
    if(!(b&1)){
        return (1<<e)*pow1(b/2,e);
    }
    else{
        return xpow(b,e);
    }
}

int xpow(int x,int n){
 x-=1;
    int mul=1;
    int j;
    int nmul=1;
    for(int i=0;i<n;i++){
        nmul=1;
for( j=0;j<=i;j++){
nmul*=(n-i);
}
int fact=1;
for(int k=1;k<=j+1;k++){
    fact*=k;
}
nmul/=fact;
mul+=nmul*pow1(x,j);

    }

return mul;
}

void main(){
    int result=pow1(3,4);
    printf("%d",result);
}