#include<stdio.h>
double xpow(double x, double n);  
double pow1(double b,int e){
    if(b==1){
        return 1;
    }
    if(((int)b %2)==0){
        return ( 1 << e)*pow1(b/2,e);
    }
    else{
        return xpow(b,e);
    }
}

double xpow(double x,double n){
 x-=1;
    double mul=1;
    int j;
    double nmul=1;
    for(int i=0;i<n;i++){
        nmul=1;
for( j=0;j<=i;j++){
nmul*=(n-i);
}
double fact=1;
for(int k=1;k<=j+1;k++){
    fact*=k;
}
nmul/=fact;
mul+=nmul*pow1(x,j);

    }

return mul;
}

int main(void){
    double result=pow1(3,4);
    printf("%f",result);
return 0;
}