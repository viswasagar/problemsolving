#include<stdio.h>
void main(){
    int n=9;
    int left=0,right=8;
    while(left<right){
       int  mid=left+(right-left)/2;
        if(mid*mid < n){
left=mid+1;
            //printf("%d",mid);
//return;
        }
        else{
            right=mid-1;
        }
    }
printf("%d",left);
}