#include<stdio.h>
int dp[100]={0};

int rec(int n){
dp[0]=1;
    for(int i=1;i<n+1;i++){
dp[i]=dp[i-1]*i;
    }
    return dp[n];
}
void main(){
    int n=6,fact=1;
    for(int i=1;i<=n;i++){
fact*=i;
    }
    int n1=rec(8);
    printf("%d",n1);


}