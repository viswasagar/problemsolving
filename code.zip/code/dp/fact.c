#include<stdio.h>
int dp[100]={0};
int recu(int n){
    if(dp[n]!=0){
        return dp[n];
    }
    if(n==0 || n==1){
        return 1;
    }
    dp[n]=n*recu(n-1);
    return dp[n];
}
void main(){
    int y=5;
    y=recu(y);
    printf("%d\n",y);
    y=recu(6);
    printf("%d\n",y);
    y=recu(8);
    printf("%d",y);
}