#include<stdio.h>
void main(){
    int arr[4]={1,2,5,20};
    int tar=21;
    int dp[tar+1];
    for(int i=0;i<tar+1;i++){
        dp[i]=44444444;
    }
    dp[0]=0;
    for(int i=0;i<4;i++){
        for(int j=arr[i];j<tar+1;j++){
            if(dp[j]-arr[i]<dp[j]){
                dp[j]=dp[j-arr[i]]+1;
            }
            else{
                dp[j]=dp[j]+1;


        }
        }}

    printf("%d",dp[tar]);
}