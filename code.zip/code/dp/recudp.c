#include<stdio.h>
int arr[4]={1,2,5,10};
int count=0;
void recu(int amount){
    if(amount==0){
        count++;
        return ;
    }
    for(int i=0;i<4;i++){
        recu(amount-arr[i]);
        for(int j=i-1;j<0;j--){
            recu(amount-arr[j]);
        }
    }
}
void main(){
recu(21);
printf("%d",count);
}