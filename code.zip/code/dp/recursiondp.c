#include<stdio.h>
int count =0;
int arr[4]={1,2,5,20};
void recu(int target,int index){
    if(target<0){
        return;
    }
    if(index>3){
        return;
    }
    if(target==0){
        count++;
        return;
    }
    recu(target-arr[index],index);
    recu(target,index+1);
}
void main(){
    recu(21,0);
    printf("%d",count);

}