#include<stdio.h>
int nax=0;
int n=10;
int arr[10]={2,-3,-2,19,18,10,9,20,132,89};
void recu(int index,int amount){
  
    if(  index ==n || index==n+1){
        if(nax<amount){
            nax=amount;
        }
        return;
    }
    recu(index+2,amount+arr[index]);
    recu(index+1,amount);
}

void main(){
recu(0,0);
printf("%d",nax);
}