#include<stdio.h>
void main(){
    int arr[4]={1,2,5,20};
int tar=21;
int dp[tar+1];
for(int i=0;i<tar+1;i++){
    dp[i]=0;
}
dp[0]=1;
for(int i=0;i<4;i++){
    for(int j=arr[i];j<tar+1;j++){
        dp[j]=dp[j]+dp[j-arr[i]];
    }
}
printf("%d",dp[tar]);
}