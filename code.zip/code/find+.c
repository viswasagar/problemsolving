#include<stdio.h>
int mat [5][5]= {
        {0, 1, 1, 0, 1},
        {0, 0, 1, 1, 1},
        {1, 1, 1, 1, 1},
        {1, 1, 1, 0, 1},
        {0, 1, 1, 1, 0}
    };
void main(){
    int i,j,k,l;
    int count;
    int maxcount=0;
    for( i=0;i<5;i++){
        for(j=0;j<5;j++){
            count=0;
            if(mat[i][j]==0){
                continue;
            }
            else{
                count++;
            }
            for(k=i-1;k>=0;k--){
                if(mat[k][j]==1){
count++;
                }
                else{
                    break;
                }
            }
            for(k=i+1;k<5;k++){
                if(mat[k][j]==1){
                    count++;
                }
                else{
                    break;
                }
            }
            for(k=j-1;k>=0;k--){
                if(mat[i][k]==1){
                    count++;
                }
                else{
                    break;
                }
            }
            for(k=j+1;k<5;k++){
                if(mat[i][k]==1){
                    count++;
                }
else{
    break;
}
            }
       
       if(count>maxcount){
            maxcount=count;
        } }
        
    }
    printf("%d",maxcount);
}