#include<stdio.h>
int mat[4][4]={{1, 3, 2, 4},
{5, 8, 7, 6},
{9, 10, 13, 11},
{12, 0, 14, 15}};

void pivott(int posi,int left,int right){
    if(right-left<=0){
        return;
    }
    int pivot = mat[posi][(left+right)/2];
    int i=left,j=right;
    while(i<=j){
        while(mat[posi][i] < pivot){
            i++;
        }
        while(mat[posi][j] > pivot){
            j--;
        }
        if(i<=j){
            int temp = mat[posi][i];
            mat[posi][i]=mat[posi][j];
            mat[posi][j]=temp;
            i++;
            j--;
        }
    }

    pivott(posi,left,i-1);
    pivott(posi,i,right);
}

void main(){
 for(int i=0;i<4;i++){
    pivott(i,0,3);
 }
 for(int i=0;i<4;i++){
    for(int j=0;j<4;j++){
        printf("%d ",mat[i][j]);
    }
    printf("\n");
 }
int target=14;
 int sum=target;
 int left=0,right=3;
 for(int i =0;i<4;i++){
    for(int j=i+1;j<4;j++){
       while(1){
        if(left > 3 || right < 0){
            break;
        }
        if(mat[i][left]+mat[j][right]==sum){
            printf("%d %d    ",mat[i][left],mat[j][right]);
            left++;
            right--;
        }
        else if(mat[i][left]+mat[j][right]<sum){
            left++;
        }
        else if(mat[i][left]+mat[j][right]>sum){
            right--;
            
        }
    }
     left=0;
 right=3;
 }

}
}