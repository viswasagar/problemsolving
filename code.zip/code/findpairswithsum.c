#include<stdio.h>
int mat[][]={{1, 3, 2, 4},
                                {5, 8, 7, 6},
                                {9, 10, 13, 11},
                                {12, 0, 14, 15}};

void sort(int i,int j){
    if(i<j){
    int mid=j/2;
    sort(i,mid-1);
    sort(mid,j);
    merge(posi,i,mid,j);
}
}
void merge(int posi,int left,int mid,int right){
    int arr1[mid-left];
    int arr2[right-mid-1];
    for(int i =0;i<mid-left;i++){
        arr1[i]=mat[posi][i];
    }
    for(int j=0;j<right-left-1;j++){
arr2[i]=mat[left][mid+j];
    }
    i=0;
    j=0;
    int k=0;
    while(i<mid-left && j<right-mid-1){
        if(arr1[i]<arr2[j]){
            mat[left][k]=arr1[i];
            k++;i++;
        }
        else{
            mat[left][k]=arr2[j];
            j++;
            k++;
        }
    }
    while(i<mid-left)
}
