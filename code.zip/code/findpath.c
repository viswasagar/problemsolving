#include<stdio.h>
int minval=9999;
int desti=3,destj=4;
int visited[9][10]; 
int bestval = 99999;
int mat [9][10]= {
        {1, 0, 1, 1, 1, 1, 0, 1, 1, 1},
        {1, 0, 1, 0, 1, 1, 1, 0, 1, 1},
        {1, 1, 1, 0, 1, 1, 0, 1, 0, 1},
        {0, 0, 0, 0, 1, 0, 0, 0, 0, 1},
        {1, 1, 1, 0, 1, 1, 1, 0, 1, 0},
        {1, 0, 1, 1, 1, 1, 0, 1, 0, 0},
        {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
        {1, 0, 1, 1, 1, 1, 0, 1, 1, 1},
        {1, 1, 0, 0, 0, 0, 1, 0, 0, 1}
    };

int issafe(int posi, int posj) {
    if (posi < 0 || posi >= 9 || posj < 0 || posj >= 10) return 0;
    if (visited[posi][posj] == 1 || mat[posi][posj] == 0) return 0;
    return 1;
}

int min1(int a,int b ,int c,int d){
    int temp=a;
    if(temp>b){
        temp=b;
    }
    if(temp > c){
        temp=c;
    }
    if(temp  >d){
        temp=d;

    }
    return temp;
}
void recursion(int posi,int posj,int dist){
  
    if(posi ==desti && posj==destj){
        if(bestval > dist){
            bestval =dist;
        }
        return;
    }
            visited[posi][posj] = 1;

    
   if(issafe(posi,posj-1)){ recursion(posi,posj-1,dist+1);
   }
    if(issafe(posi-1,posj)){
        recursion(posi-1,posj,dist+1);
    }
    if(issafe(posi+1,posj)){
          recursion(posi+1,posj,dist+1);
     }
     if(issafe(posi,posj+1)){
        recursion(posi,posj+1,dist+1);
     }
    
    visited[posi][posj] = 0;

}

void main(){
    for(int i=0;i<9;i++){
        for(int j=0;j<10;j++){
            visited[i][j]=0;
        }
    }
int sourcei=0,sourcej=0;
recursion(sourcei,sourcej,0);
    if (bestval != 99999)
        printf("Shortest path length = %d\n", bestval);
    else
        printf("No path exists!\n");

}