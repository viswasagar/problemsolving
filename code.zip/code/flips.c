#include<stdio.h>
void main(){
    int i,j;
    int flip=0;
    int arr[3][3]= {
        { 0, 0, 1 },
        { 1, 1, 1 },
        { 1, 0, 0 }
    };

    for(i=0;i<3;i++){
        for(j=i+1;j<3;j++){
            if(arr[i][j]!=arr[j][i]){
flip++;

            }
        }
    }
printf("%d",flip);
}