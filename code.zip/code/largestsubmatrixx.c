#include<stdio.h>
#include<math.h>
int mat[6][5]={{0, 1, 1, 0, 1}, 
     {1, 1, 0, 1, 0},
     {0, 1, 1, 1, 0},
     {1, 1, 1, 1, 0},
     {1, 1, 1, 1, 1},
     {0, 0, 0, 0, 0}};
     char mat1[4][4] =  {{'X','X','X','O'},
               {'X','O','X','X'},
               {'X','X','X','O'},
               {'X','O','X','X'}};
int matrecurse(int i,int j ,int *ans){
    if(i< 0|| j==4 || i==4 || j<0 ){
        return 0;
    }
    int right=matrecurse(i+0,j+1,ans);
    int down = matrecurse(i+1,j,ans);
    int diagonal = matrecurse(i+1,j+1,ans);
    if(mat1[i][j]=='O'){
        return 0;
    }
    int val = fmin(fmin(right,down),diagonal)+1;
    *ans= fmax(val,*ans);
    return val;
}
int recurse(){
    int ans=0;
    matrecurse(0,0,&ans);
    printf("%d",ans);
}
void main(){
    recurse();
}