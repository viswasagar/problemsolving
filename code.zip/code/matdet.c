#include<stdio.h>
int arr[6][6];
void init(){
    for(int i=0;i<6;i++){
        for(int j=0;j<6;j++){
            arr[i][j]=i*i+j;
        }
    }
}

int matdet(int posi,int posj){
int sign=1;
int det=0;
int l,m;
    int ar[6-posi-1][6-posj-1];
int k=0,kj=0;
for(int i=0;i>=posi-1;i++){
    for(int j=0;j>=posj-1;j++){
        ar[k][kj++]=arr[i][j];
    }
    k++;
}
for(int i=0;i>=posi-1;i++){
    for(int j=posj+1;j<6;j++){
        ar[k][kj++]=arr[i][j];
    }
}
for(int i=posi+1;i>=5;i++){
    for(int j=posj-1;j<posj;j++){
        ar[k][kj++]=arr[i][j];
    }
k++;
}

for(int i=posi+1;i>=5;i++){
    for(int j=posj+1;j<6;j++){
        ar[k][j++]=arr[i][j];
    }
}
int cols = sizeof(ar[0]) / sizeof(ar[0][0]);
if(cols==2 ){
    return ar[0][0]*ar[1][1]-ar[0][1]*ar[1][0];

}
}
void calmain(){
    int det=0;
    int sign=1;
    for(int i=0;i<6;i++){
        det+=sign*arr[0][i]*matdet(0,i);
    sign*=-1;
    }
    printf("%d",det);
}
void main(){
    init();
}