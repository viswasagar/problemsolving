#include<stdio.h>
    int mat[3][3]={{2, 7, 6}, 
                 {9, 5, 1},
                 {4, 3, 8}};
    
void pivotsort(int left,int right){
    if(right-left<=0){
        return;
    }
    int i=left,j=right;
    int mid = (left+right)/2;
        int pivot = mat[mid/3][mid%3];

    while(i<=j){
        while(mat[i/3][(i-1)%3] < pivot){
            i++;
        }
             while(mat[j/3][(j-1)%3] > pivot){
            j--;
        }
        if(i<=j){
            int temp = mat[j/3][(j-1)%3];
           mat[j/3][(j-1)%3] =mat[i/3][(i-1)%3] ;
           mat[i/3][(i-1)%3] = temp;
           i++;
           j--;
        }
    }
    pivotsort(left,i-1);
    pivotsort(i,right);
}
void main(){
pivotsort(1,10);
int i ,j;
for(i=0;i<3;i++){
    for(j=0;j<3;j++){
        printf("%d ",mat[i][j]);
    }
    printf("\n");
}
}