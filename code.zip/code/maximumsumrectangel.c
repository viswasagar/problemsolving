#include<stdio.h>
void main(){
    int mat[4][5]={{1, 2, -1, -4, -20}, 
                               {-8, -3, 4, 2, 1}, 
                               {3, 8, 10, 1, 3}, 
                               {-4, -1, 1, 7, -6}};
int toprow=0;
int maxsum =0;
int leftcolumn=0;
int bottomrow=3;
int rightcolumn =4;
for(toprow=0;toprow <=3;toprow++){
    for(leftcolumn=0;leftcolumn<=4;leftcolumn++){
        for(bottomrow=toprow;bottomrow<=3;bottomrow++){
            for( rightcolumn =leftcolumn;rightcolumn<=4;rightcolumn++){
                int sum=0;
                for(int i=toprow;i<=bottomrow;i++){
                    for(int j=leftcolumn;j<=rightcolumn;j++){
                        sum+=mat[i][j];
                    }
                }
                if(sum > maxsum){
                    maxsum=sum;

                }
            }
        }
    }
}
printf("%d",maxsum);
}