#include<stdio.h>
int mat [4][4]={{ 1, 2, -1, 4 },
    { -8, -3, 4, 2 },
    { 3, 8, 10, -8 },
    { -4, -1, 1, 7 } };
void main(){
int i,j,k,l;
int sum,maxsum=0;
for(i=0;i<=4-3;i++){
    for(j=0;j<=4-3;j++){
        sum=0;
        for(k=i;k<i+3;k++){
            for(l=j;l<j+3;l++){
                sum+=mat[k][l];
            }
        }
        if(sum>maxsum){
            maxsum=sum;
        }
    }
}
printf("%d",maxsum);
}