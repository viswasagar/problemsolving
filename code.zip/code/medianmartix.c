#include<stdio.h>
void main(){
    int mat[3][3]={{1, 3, 5}, 
                               {2, 6, 9}, 
                               {3, 6, 9}};
int i,j,temp,count=0;
j=-1;
while(1){


    j++;
    d
    for(i=0;i<3;i++){
        if(mat[j][i] < temp)
        {
            printf("IT IS THE median %d ",mat[j][i]);
        }
        else{
            printf("IT IS TEH MEDIAN %d ",temp);
        }

    }

}
}