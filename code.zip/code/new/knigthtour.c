#include<stdio.h>
int cell=0;
int n=5;
int visited[5][5];
int found=0;
void inint(){
    for(int i =0;i<5;i++){
        for(int j=0;j<5;j++){
            visited[i][j]=0;
        }
    }
}
void printboard(){
    for(int i=0;i<n;i++){
        printf("\n");
        for(int j=0;j<n;j++){
            printf("%d ",visited[i][j]);
        }
    }
}
int validmove(int posi,int posj,int type){
    if(type==1){
        if(posi+2 <n && posi+2 >=0 && posj+1 < n && posj+1 >=0 && !visited[posi+2][posj+1]){
            return 1;
        }
        else{
            return 0;
        }

    }
    if(type==2){
         if(posi+2 <n && posi+2 >=0 && posj-1 < n && posj-1 >=0 && !visited[posi+2][posj-1]){
            return 1;
        }
        else{
            return 0;
        }
    }

      if(type==3){
 if(posi-2 <n && posi-2 >=0 && posj+1 < n && posj+1 >=0 && !visited[posi-2][posj+1]){
            return 1;
        }
        else{
            return 0;
        }

    }
    if(type==4){
 if(posi-2 <n && posi-2 >=0 && posj-1 < n && posj-1 >=0 && !visited[posi-2][posj-1]){
            return 1;
        }
        else{
            return 0;
        }
    }
  if(type==5){
 if(posj+2 <n && posj+2 >=0 && posi+1 < n && posi+1 >=0 && !visited[posi+1][posj+2]){
            return 1;
        }
        else{
            return 0;
        }

    }
    if(type==6){
 if(posj+2 <n && posj+2 >=0 && posi-1 < n && posi-1 >=0 && !visited[posi-1][posj+2]){
            return 1;
        }
        else{
            return 0;
        }
    }
  if(type==7){
 if(posj-2 <n && posj-2 >=0 && posi+1 < n && posi+1 >=0 && !visited[posi+1][posj-2]){
            return 1;
        }
        else{
            return 0;
        }

    }
    if(type==8){
 if(posj-2 <n && posj-2 >=0 && posi-1 < n && posi-1 >=0 && !visited[posi-1][posj-2]){
            return 1;
        }
        else{
            return 0;
        }
    }

    return 0;

}
void tour(int moved,int posi,int posj){
    // if(found){
    //     return;
    // }
    if(moved==n*n){
printboard();
//found=1;
        return;
    }
    if(validmove(posi,posj,1)){
        visited[posi+2][posj+1]=moved+1;
        tour(moved+1,posi+2,posj+1);
     visited[posi+2][posj+1]=0;

    } 
 if(validmove(posi,posj,2)){
        visited[posi+2][posj-1]=moved+1;
        tour(moved+1,posi+2,posj-1);
     visited[posi+2][posj-1]=0;

    } 

 if(validmove(posi,posj,3)){
        visited[posi-2][posj+1]=moved+1;
        tour(moved+1,posi-2,posj+1);
     visited[posi-2][posj+1]=0;

    } 

 if(validmove(posi,posj,4)){
        visited[posi-2][posj-1]=moved+1;
        tour(moved+1,posi-2,posj-1);
     visited[posi-2][posj-1]=0;

    } 

 if(validmove(posi,posj,5)){
        visited[posi+1][posj+2]=moved+1;
        tour(moved+1,posi+1,posj+2);
     visited[posi+1][posj+2]=0;

    } 
 if(validmove(posi,posj,6)){
        visited[posi-1][posj+2]=moved+1;
        tour(moved+1,posi-1,posj+2);
     visited[posi-1][posj+2]=0;

    } 

     if(validmove(posi,posj,7)){
        visited[posi+1][posj-2]=moved+1;
        tour(moved+1,posi+1,posj-2);
     visited[posi+1][posj-2]=0;

    } 
     if(validmove(posi,posj,8)){
        visited[posi-1][posj-2]=moved+1;
        tour(moved+1,posi-1,posj-2);
     visited[posi-1][posj-2]=0;

    } 

}

void main(){
    inint();
    visited[0][0]=1;
    tour(1,0,0);
    // for(int i =0;i<n;i++){
    //     for(int j=0;j<n;j++){
    //         printf("%d  ",visited[i][j]);
    //     }
    //     printf("\n");
    // }
   
}