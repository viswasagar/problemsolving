#include<stdio.h>
#define n 2
int arr[3][2];
int temp[2];
int i=0;

void recu(int start,int k){
    if(k==0){
        arr[i][0]=temp[0];
        arr[i][1]=temp[1];
        i++;
        return;
    }
    for(int f=start;f<4;f++){
        
        temp[2-k]=f;
        recu(f+1,k-1);
        
    }
}
void main(){
recu(1,2);
for(int k=0;k<3;k++){
    printf("\n");
    printf("%d  %d",arr[k][0],arr[k][1]);
}
}