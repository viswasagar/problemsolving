 #include<stdio.h>
int arr[3][2];
int temp[2];
int in=0;
void recu(int start,int k){
    if(k==0){

        arr[in][0]=temp[0];
        arr[in][1]=temp[1];
        in++;
        return;
    }
    for(int i=start;i<3;i++){
        temp[2-k]=i;
        recu(start+1,k-1);
    }
}

void main(){
    recu(0,2);
    int n;

    for( n=0;n<3;n++){
        printf("\n %d %d",arr[n][0],arr[n][1]);
    }
    printf("\n%d %d",arr[n][0],arr[n][1]);
    printf("\n%d %d",arr[n+1][0],arr[n+1][1]);
}
