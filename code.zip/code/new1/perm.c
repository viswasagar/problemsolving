#include<stdio.h>
#define N 3
int perm1[2*N][3];
int arr[N];
int sub[N];
int i=0;
void perm(int index){
    if(index==N){
        perm1[i][0]=arr[0];
        perm1[i][1]=arr[1];
        perm1[i][2]=arr[2];
        i++;
        return;

    }
int j;
    for( j=index;j<N;j++){
        
        int ar=arr[index];
    arr[index]=arr[j];
    arr[j]=ar;
    // else{
    //     int ar=arr[(j+1)%N];
    //     arr[(j+1)%N]=arr[j];
    //     arr[j]=ar;
    // }
    perm(index+1);
int temp=arr[index];
arr[index]=arr[j];
arr[j]=temp;
}
    // int k;
    // for(k=0;k<index;k++){
    //     int temp=arr[k];
    //     arr[k]=arr[k+1];
    // arr[k+1]=temp;
    // perm(index+1);
    // }
    // }
}



void main()
{
    sub[0]=1;
    sub[1]=2;
    sub[2]=3;
    arr[0]=1;
    arr[1]=2;
    arr[2]=3;
perm(0);
for(int f=0;f<2*N;f++){
    printf("\n");
    for(int o=0;o<N;o++){
        printf("%d",perm1[f][o]);
    }
}
}