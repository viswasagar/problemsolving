#include<stdio.h>
#define N 3
int i=0;
int arr[N];
int perm[N*2][3];
void init(){
    arr[0]=1;
    arr[1]=2;
    arr[2]=3;
}

void recu(int index){
    if(index==N){
        perm[i][0]=arr[0];
        perm[i][1]=arr[1];
        perm[i][2]=arr[2];
        i++;
        return;
    }
    int j;
    for(j=index;j<N;j++){
        int ar=arr[index];
       // arr[j]=arr[index];
        arr[index]=arr[j];
        arr[j]=ar;
        recu(index+1);
       // int temp= arr[index];
        arr[index]=arr[j];
        arr[j]=ar;
    }

}
void main(){
    init();
    recu(0);
    for(int k=0;k<2*N;k++){
        printf("\n");
        printf("%d %d %d",perm[k][0],perm[k][1],perm[k][2]);
    }
}