#include<stdio.h>
#define N 3
int subset[N],power[1<<N][N];
int i=0,j=0;
int arr[N];

void recur(int k ){
    if(k==N){
        power[i][0]=subset[0];
        power[i][1]=subset[1];
        power[i][2]=subset[2];
        i++;
        return;
    }
    subset[k]=0;
    recur(k+1);
    subset[k]=arr[k];
    recur(k+1);

    

}
void main(){
    arr[0]=1;
    arr[1]=2;
    arr[2]=3;
    recur(0);
for(int i=0;i<1<<N;i++){
    printf("\n");
    for(int j=0;j<N;j++){
        printf("%d",power[i][j]);
    }
}
}