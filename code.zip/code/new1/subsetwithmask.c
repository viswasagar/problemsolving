#include<stdio.h>
void main(){
    int arr[3]={1,2,3};
    for(int i=0;i<1<<3;i++){
        printf("\n{");
        for(int j=0;j<3;j++){
            if(i&(1<<j)){
                printf("%d",arr[j]);
            }
        }
        printf("}");
    }
}