sub="12243660"
n=8
def recu(start,len1,len2,len3):
    if(int(sub[start:start+len1]) == (int(sub[start+len1:start+len1+len2])+int(sub[start+len1+len2:start+len1+len2+len3]))):
        return 
    for i in range(start,n,1):
        j=1
        k=1
        l=1
        recu(start+j,start+j,start+k+j,start+k+l+j)
        k+=1
        recu(start+j,start+j,start+k+j,start+k+j+l)
        l+=1
        recu(start+j,start+j,start+k+j,start+k+j+l)
        k-=1
        recu(start,+j,start+j,start+k+j,start+k+j+l)

recu(0,0,0,0)