string="12243660"
n=len(string)
def recu(start,len1,len2,len3):
    if len1 >0 and len2 >0 and len3 >0 :
        part1=int(string[start:start+len1])
        part2=int(string[start+len1:start+len1+len2])
        part3=int(string[start+len1+len2:start+len1+len2+len3])
        if part3 == part1+part2:
            print(part3,part1,part2)
        return
    if len1 ==0:
        for l1 in range(1,n-start):
            recu(start,l1,len2,len3)
    elif len2==0:
        for l2 in range (1,n-start-len1):  
            recu(start,len1,l2,len3)
    elif len3==0:
        for l3 in range(1,n-start-len1-len2+1):
            recu(start,len1,len2,l3)

recu(0,0,0,0)