#include<stdio.h>
    int mat[3][3]={{2, 7, 6}, 
                 {9, 5, 1},
                 {4, 3, 8}};
    
void pivotsort(int left,int right){
    if(right-left<=0){
        return;
    }
    int i=left,j=right;
    int mid = (left+right)/2;
        int pivot = mat[mid/3][mid%3];

    while(i<=j){
        while(mat[i/3][(i)%3] < pivot){
            i++;
        }
             while(mat[j/3][(j)%3] > pivot){
            j--;
        }
        if(i<=j){
            int temp = mat[j/3][(j)%3];
           mat[j/3][(j)%3] =mat[i/3][(i)%3] ;
           mat[i/3][(i)%3] = temp;
           i++;
           j--;
        }
    }
    pivotsort(left,i-1);
    pivotsort(i,right);
}
void main(){
int total = 3 *(3*3+1)/2;
int row,col,sum,i ,j;
i=0;
j=0;
while (j!=3){
    sum=0;
    for(row=0;row<3;row++){
        sum+=mat[row][j];
    }
    if(sum != total){
        printf("Not Magiccal Square of Odd Order");
    }
j++;

}
i=0;
while (i!=3){
    sum=0;
    for(col=0;col<3;col++){
        sum+=mat[i][col];
    }
    if(sum != total){
        printf("Not Magiccal Square of Odd Order");
    }
i++;

}
sum=0;
for(i=0;i<3;i++){
sum+=mat[i][i];
}
  if(sum != total){
        printf("Not Magiccal Square of Odd Order");
    }
sum=0;
for(i=2;i>=0;i--){
    sum+=mat[i][i];
}
  if(sum != total){
        printf("Not Magiccal Square of Odd Order");
    }

pivotsort(0,8);

int count =1;
for(i=0;i<3;i++){
    for(j=0;j<3;j++){
        printf("%d ",mat[i][j]);
    }
    printf("\n");
}
for(i=0;i<3;i++){
    for(j=0;j<3;j++){
        if(mat[i][j]!=count){
                    printf("Not Magiccal Square of Odd Order");

        }
        count++;
    }
}
printf("IT IS A MAgical MAtrix");
}