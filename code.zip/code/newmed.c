#include<stdio.h>
int mat[3][3]={{1, 3, 4}, 
                               {2, 5, 6}, 
                               {3, 7, 9}};
void main(){
    int min=99999,max=0,posi,posj;
    for(int i =0;i<3;i++){
        if(min > mat[i][0]){
            posi=i;
            min=mat[i][0];
        }
    }
    for(int i=0;i<3;i++){
        if(max < mat[i][2]){
            max = mat[i][2];
        posj=i;    
        }
    }
    int mid,count=0;
    int flag=0;
    int target=5;
while(min<max){
    mid=min+(max-min)/2;
posi=0;
posj=0;
count=0;

    while(posi!=3){
        if(mat[posi][posj] <= mid){
            count++;
    
            if(posj+1!=3){
                posj++;
            }
            else{
                posi++;
                posj=0;
            }
        }
        else{
            posi++;
            posj=0;

        }
    }
    if(count>target){
        max=mid-1;
    }
    else if(count<target){
        min=mid+1;
    }
    else{
        printf("%d            ",mid);
        flag=1;
        break;
    }
  
}

if(flag==0){
    printf("mid is %d",mid+1);
}
}
