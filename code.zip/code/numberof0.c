#include<stdio.h>
void main(){
    int mat[5][5]={ { 0, 0, 0, 0, 1 },
        { 0, 0, 0, 1, 1 },
        { 0, 1, 1, 1, 1 },
        { 1, 1, 1, 1, 1 },
        { 1, 1, 1, 1, 1 }
    };
int count=0;
int pi=4,pj=0;
while(1){
   
    if(mat[pi][pj]!=0){
         if(pi==0 || pj==4){
    count+=pi+1;
        break;
    }
        pi--;
    } 
    else{
        count+=pi+1;
        pj++;
    }
}

printf("%d",count-1);
}