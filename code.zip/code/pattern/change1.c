#include<stdio.h>
int mat[3][4]={{1, 0, 0, 1}, {0, 0, 1, 0}, {0, 0, 0, 0}};
void makenegative(int posi,int posj){
int row=0;
for(;row<3;row++){
    mat[row][posj]=-1;
}
for(row=0;row<4;row++){
    mat[posi][row]=-1;
}
}
void main(){
    for(int i =0;i<3;i++){
        for(int j =0;j<4;j++){
            if(mat[i][j]==1){
                makenegative(i,j);
            }
        }
    }

    for(int i=0;i<3;i++){
        for(int j=0;j<4;j++){
            if(mat[i][j]==-1){
                mat[i][j]=1;
            }
        }

    }
    for(int i=0;i<3;i++){
        for(int j=0;j<4;j++){
            printf("%d",mat[i][j]);
        }
        printf("\n");
    }
}
