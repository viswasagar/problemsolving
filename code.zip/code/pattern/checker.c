#include<stdio.h>
int min1(int a ,int b ,int c,int d){
    if(a<b){
        if(a<c){
            if(a<d){
                return a;
            }
            else{
                return d;
            }
        }
        else if(c<d){
            return c;
            
        }
        else{return d;}
    }
    else if(b<c){
        if(b<d){
            return b;
        }
        else {
            return d;
        }
    }
    else if(c<d){
        return c;

    }
    else{
        return d;
    }
}

void main(){
    int n=4;

    for(int i=0;i<n;i++){
        for(int j =0;j<n;j++){
int min=min1(i,j,n-i,n-j);
int base=n-min;
if((i+j)%2==0){
    printf("%d",base);
}
else{
    printf("%d",base-1);
}
        }
        printf("\n");
    }
}