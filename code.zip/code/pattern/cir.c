#include<stdio.h>
#include<math.h>
void main(){
    float raduis=4;
    for(int i =0;i<=2*raduis;i++){
        for(int j=0;j<=2*raduis;j++){
            float dist=sqrt((i-raduis)*(i-raduis)+(j-raduis)*(j-raduis));
            if(dist <= raduis+0.5 && dist >= raduis-0.5){
                printf("*");
            }
            else{
                printf(" ");
            }
        }
        printf("\n");
    }
}