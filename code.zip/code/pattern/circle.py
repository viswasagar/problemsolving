n=3
for i in range(n):
    if i==0:
        print(" "*(n-1),"*"*n)
        continue
    if i==1:
        print(""*(n-2),"*"*n)
        continue
    print("*",""*(2*n-1),"*")
for i in range(n-1):
    if i==n-2:
        print(""*(n-1),"*"*n)
        continue
    print(""*(n-2),""*n,"*")