#include<stdio.h>
char grid[27][27];
void recu(int r,int c ,int size){
    if(size==1){
        grid[r][c]='*';
        return;
    }
    int newsize=size/3;
    recu(r+newsize,c+newsize,newsize);
    recu(r,c+newsize,newsize);
    recu(r+2*newsize,c+newsize,newsize);
    recu(r+newsize,c,newsize);
    recu(r+newsize,c+2*newsize,newsize);
}
void init(){
    for(int i=0;i<27;i++){
        for(int j=0;j<27;j++){
            grid[i][j]=' ';
        }
    }
}

void main(){
    init();
    recu(0,0,27);
    for(int i=0;i<27;i++){
        for(int j=0;j<27;j++){
            putchar(grid[i][j]);
        }
    putchar('\n');

    }
        printf("\n");
    }