#include<stdio.h>
int min1(int a ,int b ,int c,int d){
    if(a<b){
        if(a<c){
            if(a<d){
                return a;
            }
            else{
                return d;
            }
        }
        else if(c<d){
            return c;
            
        }
        else{return d;}
    }
    else if(b<c){
        if(b<d){
            return b;
        }
        else {
            return d;
        }
    }
    else if(c<d){
        return c;

    }
    else{
        return d;
    }
}

void main(){
    int n=4;
    int size=(2*n)-1;
    int i ,j;
    for(i=0;i<size;i++){
        for(j=0;j<size;j++){
            int min = min1(i,j,size-1-i,size-1-j);
            printf("%d",n-min);
        }
        printf("\n");
    }
}