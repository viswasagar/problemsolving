#include <stdio.h>

/**
 * Function to print the concentric square pattern
 * @param n: The starting (outermost) number
 */
void printConcentricPattern(int n) {
    int size = (2 * n) - 1; // Total rows/columns

    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            // Find the minimum distance from the current cell to all four edges
            int top = i;
            int left = j;
            int bottom = size - i - 1;
            int right = size - j - 1;

            // The value at (i, j) is n minus the minimum distance to an edge
            int min_dist = top;
            if (left < min_dist) min_dist = left;
            if (bottom < min_dist) min_dist = bottom;
            if (right < min_dist) min_dist = right;

            printf("%d", n - min_dist);
        }
        printf("\n");
    }
}

int main() {
    int n = 4; // Your target input
    printConcentricPattern(n);
    return 0;
}
