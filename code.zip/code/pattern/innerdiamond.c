int cal(int x){
    if(x<0){
        return (x*-1);
    }
    else{
        return x;
    }
}
#include<stdio.h>
void main(){
int mid=20;
for(int i=0;i<=mid;i++){
    for(int j=0;j<=2*mid;j++){
    if(cal(mid-i)+cal(mid-j)==mid){
        printf("*");
    }
    else if(i!=0 &&  ((i+cal(mid-i)+cal(mid-j)==mid-1+i))){
        printf("*");
    }
     else if(i!=1 &&  ((i+cal(mid-i)+cal(mid-j)==(mid-2)+i))){
        printf("*");
    }
      else if(i!=2 &&  ((i+cal(mid-i)+cal(mid-j)==(mid-3)+i))){
        printf("*");
    }
    else{
        printf(" ");
    }
}
printf("\n");
}
for(int i=mid+1;i<=2*mid;i++){
    for(int j=0;j<=2*mid;j++){
    if(cal(mid-i)+cal(mid-j)==mid){
        printf("*");
    }
    else if(i!=0 &&  ((i+cal(mid-i)+cal(mid-j)==mid-1+i))){
        printf("*");
    }
     else if(i!=1 &&  ((i+cal(mid-i)+cal(mid-j)==(mid-2)+i))){
        printf("*");
    }
       else if(i!=2 &&  ((i+cal(mid-i)+cal(mid-j)==(mid-3)+i))){
        printf("*");
    }
    else{
        printf(" ");
    }
}
printf("\n");
}

}