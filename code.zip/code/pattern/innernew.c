#include<stdio.h>
int min(int a ,int b)
{
    return (a<b)?a:b;
}
void main(){
    int n =4;
    int size=2*n-1;
    int row=size,col=size;
    for(int i=0;i<row;i++){
        for(int j=0;j<col;j++){
            if(i==0 || j==0 || i==size-1 || j==size-1){
                printf("%d",n);
                continue;
            }
            if(j==i || j==size-1-i){
                printf("%d",n-min(i,size-1-i));
                continue;
            }
            printf(" ");
        }
        printf("\n");
    }
}