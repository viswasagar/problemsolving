#include<stdio.h>
void main(){
    int n =4;
    int size=(2*n-1);
    int front =0,back=size-1;
    int mat[size][size];
    while(n!=0){
        for(int i=front;i<=back;i++){
            for(int j=front;j<=back;j++){
                if(i==front || i==back || j==front || j==back)
                {
                        mat[i][j]=n;    
                    }   
         }
        }
        ++front;
        --back;
        --n;
        
    }
    for(front =0;front<=size-1;front++){
        for(back=0;back<=size-1;back++){
            printf("%d",mat[front][back]);
        }
        printf("\n");
    }
}