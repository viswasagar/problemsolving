#include<stdio.h>
void main(){
    int n=4;
    int size=(2*n-1);
    for(int i =0;i<size;i++){
        for(int j=0;j<size;j++){
            int  mindist = min(i,j,size-i-1,size-j-1);
            if(i==0 || j==size-1 || j==0){
                printf("%d",n);
            }
            for(int k=0;k<mindist;k++){
                printf(" ");
            }
            printf("%d",n-mindist);
            
        }
    }
}