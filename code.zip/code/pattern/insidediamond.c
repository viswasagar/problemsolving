#include<stdio.h>
void main(){
    int n=10;
    int p=0;
    for(int i=n;i>0;i--,p++){
        for(int j=0;j<(n-p);j++){
            printf("*");
        }
        if(i!=n){
        for(int k=0;k<2*(n-i)+1;k++){
            if(i==n){
                printf(" ");
                break;
            }
            printf(" ");
        }
    }
    else{

        printf(" ");
            }
                    for(int j=0;j<(n-p);j++){
            printf("*");
        }
        printf("\n");
    }
    p=n-1;
    for(int i=0;i<n;i++,p--){
        for(int j=0;j<(n-p);j++){
            printf("*");
        }
        if(i!=n-1){
        for(int k=0;k<2*(n-i-1)+1;k++){
        
            printf(" ");
        }
    }
    else{printf(" ");}

        for(int j=0;j<(n-p);j++){
            printf("*");
        }
        printf("\n");
    }
}
