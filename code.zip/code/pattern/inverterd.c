#include<stdio.h>
void main(){
    int n=10;
    for(int i =0;i<n;i++){
        for(int k=0;k<i;k++){
            printf(" ");
        }
        for(int j=0;j<(2*(n-1-i))+1;j++){
            printf("*");
        }
        printf("\n");
    }
}