#include<stdio.h>
void main(){
    int n=20;
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            if(i==0){
                printf("*");
                continue;
            }
            if(j==n/2){
                printf("*");
            }
            else if(j==i-n/2){
printf("*");
if(i==n-1){
    printf("");
}
continue;
            }
            else if(j<n/2){
                printf(" ");
            }

        }
        printf("\n");
    }
}