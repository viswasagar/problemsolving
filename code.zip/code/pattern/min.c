#include<stdio.h>
int min(int a ,int b,int c ,int d){
    if(a<b){
        if(a<c){
            if(a<d){
                return a;
            }
            else{
                return d;
            }
        }
        else if(c<b){
            if (c<d){
                return c;
            }
            return d;
        }
}
else if(b<c){
    if(b<d){
        return b;

    }
    else if (d<c){
        return d;
    }
    else{
        return c;
    }
}
}
void main(){
    printf("%d",min(5,4,3,2));
}