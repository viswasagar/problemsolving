#include<stdio.h>
void main(){
    int n=20;
    int first=1;
    for(int i=0;i<6;i++){ 
        if(i==0){
            first=1;
        }
        else{
            first=0;
        }
        for(int j=0;j<=100;j++){
            if(first==0){
            if((i+j)%n==0){
                printf("*");
            }
            else{
                printf(" ");
            }
        }
    
        }
        
        printf("\n");
    }
}
