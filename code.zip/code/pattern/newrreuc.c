#include <stdio.h>

int main() {
    int n;
    printf("Enter n: ");
    scanf("%d", &n);

    // 1) Create and initialize grid with spaces
    char grid[n][n];
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            grid[i][j] = ' ';

    // 2) Draw frames layer by layer
    int start = 0, end = n - 1;
    while (start <= end) {
        // Top and bottom rows of this layer
        for (int j = start; j <= end; j++) {
            grid[start][j] = '*';
            grid[end][j]   = '*';
        }
        // Left and right columns of this layer
        for (int i = start; i <= end; i++) {
            grid[i][start] = '*';
            grid[i][end]   = '*';
        }

        // Move inward by 2 to keep spacing between frames
        start += 2;
        end   -= 2;
    }

    // 3) Print the grid with spaces between characters
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            printf("%c ", grid[i][j]);
        }
        printf("\n");
    }

    return 0;
}