#include<stdio.h>
void recu(int n,int fix,int grow,int shrink){
    if(grow == 0 && shrink==0){
        return;
    }
    
    if(grow==1){
        if(n+5 >= fix){
        printf("%d ",n+5);
        
        recu(n+5,fix,0,0);
        }
        else{
             printf("%d ",n+5);
        
        recu(n+5,fix,1,0);
        }
    }

    if(shrink==1){
        if(n-5 <= 0){
        printf("%d ",n-5);
        
        recu(n+5,fix,1,0);
        }
        else{
             printf("%d ",n-5);
        
        recu(n-5,fix,0,1);
        }
    }

}
void main(){
    recu(16,16,0,1);
}