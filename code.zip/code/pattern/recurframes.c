#include<stdio.h>
void main(){
    int n=8;
    int start=0;
    int end=n-1;
    char grid[n][n];
    for(int i =0;i<n;i++){
        for(int j=0;j<n;j++){
            grid[i][j]=' ';
        }
    }
    while(start<=end){
        for(int i=start;i<=end;i++){
            grid[start][i]='*';
            grid[end][i]='*';
        }
        grid[start][start]='*';
        grid[start][end]='*';
        grid[end][start]='*';
        grid[end][end]='*';
        start+=2;
        end-=2;
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            printf("%c ",grid[i][j]);
        }
        printf("\n");
    }
}