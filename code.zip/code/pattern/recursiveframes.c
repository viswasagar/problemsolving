#include<stdio.h>
void main(){
    int n=9;
    int start,end;
    char grid[n][n];
    for(int i =0;i<n;i++){
        for(int j=0;j<n;j++){
            grid[i][j]=' ';
        }
    }
    start=0;
    end=n-1;
    while(start<=end){
        for(int i=start;i<=end;i++){
            grid[start][i]='*';
            grid[i][start]='*';
            grid[end][i]='*';
            grid[i][end]='*';
        }
        start+=2;
        end-=2;
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            printf("%c ",grid[i][j]);
        }
    printf("\n");
    }
}