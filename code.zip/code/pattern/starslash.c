#include<stdio.h>
void main(){
    int n=9;
    for(int i=(n/2+1);i>0;i++){
        for(int k=(n/2+1);k>i;k--){
            printf("*");
        }
        printf("\");
        for(j=0;j<=(2*(n-i)))
    }
}