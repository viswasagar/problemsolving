#include<stdio.h>
void main(){
    int m=2;
    int y=50;
    int x;
    int c=2;
    for(;y>=0;y--){
        for(int k=50;k>=0;k--){
           // printf("      ");
        }
        int temp=(y-c)/m;
        printf("\n");
        for(x=0;x<=temp+10;x++){
            if(x==0 && y==0){
                printf("+");
            }
            else if(x==0){
                printf("|");
            }
          
            else if((x*m+c)==y){
                printf("-");
            }            
            else{
                printf(" ");
            }
            }
        }
        for(y=-1;y>=-50;y--){
         for(int k =50;k>=0;k--){
           // printf(" ");
        }
            int temp=(y-c)/m;
            printf("\n");
            for(x=0;x>=temp-10;x--){
               if(x==0 && y==0){
                printf("+");
            }
            else if(x==0){
                printf("|");
            }
          
            else if((x*m+c)==y){
                printf("-");
            }            
            else{
                printf(" ");
            } 
            }
        }

    }
