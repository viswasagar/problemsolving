n=7
print(int(n/2),n//2)
for i in range(n//2 +1):
    if i==0:
          print("*",""*(n//2-1),"*"*(n//2+1))
          continue
    if i==n//2:
         print("*"*n)
         continue
    print("*",""*(n//2-1),"*")
for i in range(n//2):
   if i==n//2-1:
        print("*"*(n//2+1),""*(n//2),"*")
        continue
   print(" "*(n//2-1),"*",""*(n//2-1),"*")
