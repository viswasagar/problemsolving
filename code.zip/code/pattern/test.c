#include <stdio.h>
#include <stdlib.h>

/*
  Generate n rows following this rule:
  - Compute row by Pascal sums from previous row.
  - After computing, subtract 1 from the rightmost element (index r).
  - Use the reduced row as prev for the next iteration.
*/

int main(void) {
    int n;
    if (scanf("%d", &n) != 1 || n <= 0) return 0;

    long long *prev = malloc(sizeof(long long) * n);
    long long *row  = malloc(sizeof(long long) * n);
    if (!prev || !row) return 1;

    // Row 0
    prev[0] = 1;
    printf("%lld\n", prev[0]);

    for (int r = 1; r < n; ++r) {
        // edges
        row[0] = 1;
        row[r] = 1;

        // standard Pascal inner sums
        for (int k = 1; k < r; ++k) {
            row[k] = prev[k-1] + prev[k];
        }

        // reduction: subtract 1 from the rightmost element
        row[r] = row[r] - 1;

        // print row
        for (int k = 0; k <= r; ++k) {
            if (k) putchar(' ');
            printf("%lld", row[k]);
        }
        putchar('\n');

        // swap buffers so reduced row becomes prev
        long long *tmp = prev;
        prev = row;
        row = tmp;
    }

    free(prev);
    free(row);
    return 0;
}