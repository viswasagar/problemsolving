#include<stdio.h>
void main(){
    int flag=0;

    for(int i=0;i<8;i++){
       // flag^=temp;
        //temp^=flag;
       // flag^=temp;
       flag^=1;
        for(int j=0;j<8;j++){
        if(flag==1){
            if((i+j)%2==0){
                printf("*");
            }
            else{
                printf(" ");
            }
        }
        else{
             if((i+j)%2==0){
                printf("*");
            }
            else{
                printf(" ");
            }
        }
        }
        printf("\n");
    }
}