#include<stdio.h>
void main(){
    int n=12;
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            if(i<n/2 && j==0){
                printf("*");
                continue;
            }
            if(i<n/2 && j==n-1){
                printf("*");
                continue;
            }

            else if(i<n/2){
                printf(" ");
                continue;
            }
            if(i==n-2){

                for(int k=0;k<n/2-1;k++){
                    printf(" ");

                }
                printf("**");
            return;
            }

            if(j==(i+n/2-n) && i>=n/2){
                printf("*");
                continue;
            }
            else if(i>=n/2){
                printf(" ");
            }
            if(i>=n/2 && j==(n-i-n/2-1+n-1)){
                printf("*");
            }
        }
        printf("\n");
    }
}