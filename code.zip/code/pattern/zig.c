#include <stdio.h>

int main() {
    int n = 12;      // height
    int tog = 1;     // toggle

    for (int i = 0; i < n; i++) {
        // leading diagonal shift
        for (int k = 0; k < i; k++) {
            printf(" ");
        }
        printf("*");

        // inner zigzag
        for (int j = 0; j < n; j++) {
            if (i == 0 || i == n - 1) {
                // top/bottom rows: fixed spacing to avoid "**"
                for (int k = 0; k < 2 * (n - 1) - 1; k++) {
                    printf(" ");
                }
                printf("*");
                continue;
            }

            if (tog == 1) {
                int gap = 2 * (n - 1 - i) - 1; // shrinking
                if (gap > 0) {
                    for (int k = 0; k < gap; k++) printf(" ");
                    printf("*");
                }
            } else {
                int gap = (2 * i) - 1; // expanding
                if (gap > 0) {
                    for (int k = 0; k < gap; k++) printf(" ");
                    printf("*");
                }
            }
            tog ^= 1; // continuous flip
        }
        printf("\n");
    }
    return 0;
}