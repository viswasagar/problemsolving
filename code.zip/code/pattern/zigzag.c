#include<stdio.h>
void main(){
    int tog=1;
    int n=30;
    for(int i=0;i<n;i++){
        tog=1;
        for(int k=0;k<=i-1;k++){
            printf(" ");
        }
        printf("*");
        for(int j=0;j<n*2;j++){
            if(i==0 || i==n-1){
                if(j>2*n/2 -1){
                    continue;
                }
      if(i==0){
          for(int k=0;k<2*((n-1)-i)-1;k++){
                    printf(" ");
                }
                printf("*");
      }
      if(i==n-1){
         for(int k=0;k<(2*i)-1;k++){
                    printf(" ");
                }
                printf("*");
      }
         continue;
           }
            if(tog==1){
                int gap=2*(n-1-i)-1;
                if(gap>0){
                for(int k=0;k<2*((n-1)-i)-1;k++){
                    printf(" ");
                }
                printf("*");
            }
        }
            else{
               int gap=2*i-1;
               if(gap>0){
                for(int k=0;k<(2*i)-1;k++){
                    printf(" ");
                }
                printf("*");
            }
        }
            tog^=1;
        
    }
    printf("\n");
    }
}