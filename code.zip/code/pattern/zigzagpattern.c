#include<stdio.h>
void main(){
    int tog=1;
    int n=4;
    for(int i=0;i<4;i++){
        //tog^=1;
        for(int k=0;k<=i;k++){
            printf(" ");
        }
        printf("*");
        for(int j=0;j<8;j++){
            if(i==0 || i==3){
                if(j>n*2/2 -1){
                    continue;
                }
      if(i==0){
          for(int k=0;k<2*(n-i)-1;k++){
                    printf(" ");
                }
                printf("*");
      }
      if(i==n-1){
         for(int k=0;k<(2*i)-1;k++){
                    printf(" ");
                }
                printf("*");
      }
         continue;
           }
            if(tog==1){
                for(int k=0;k<2*(n-i)-1;k++){
                    printf(" ");
                }
                printf("*");
            }
            else{
                for(int k=0;k<(2*i)-1;k++){
                    printf(" ");
                }
                printf("*");
            }
            tog^=1;
        
    }
    printf("\n");
    }
}