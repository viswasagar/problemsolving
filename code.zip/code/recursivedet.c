#include<stdio.h>
int recu(int n,int mat[n][n]){
    if(n==1){
        return mat[0][0];
    }
    if(n==2){
        return (mat[0][0]*mat[1][1]-mat[0][1]*mat[1][0]);
    }
    int det=0;
    int sign=1;
    int minor[n-1][n-1];
    for(int col=0;col<n;col++){
    int mrow=0;
        for(int i=1;i<n;i++){
            int mcol=0;
       for( int j=0;j<n;j++){
        if(j==col){
            continue;
        }
minor[mrow][mcol]=mat[i][j];
mcol++;
       }
       mrow++;
    }            
           det+=mat[0][col]*sign*recu(n-1,minor);
               sign*=-1;
    }
    return det;

}
void main()
{
//int arr[5][5]={{1,6,8,4,5},{7,2,3,9,10},{11,14,13,14,15},{15,17,18,19,20},{24,22,23,24,25}};
//int arr[5][5]={{10,1,22,3,4},{5,6,7,8,9},{10,10,11,12,14},{15,16,15,17,18},{20,20,21,22,23}};
int arr[5][5] = {
    {5, 2, 1, 0, 0},
    {0, 6, 2, 1, 0},
    {0, 0, 7, 2, 1},
    {0, 0, 0, 8, 2},
    {0, 0, 0, 0, 9}
};
int det=recu(5,arr);
printf("%d",det);
}