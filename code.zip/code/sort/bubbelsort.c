#include<stdio.h>
int arr[]={435,54,657,654,34,34,56,76,87,65,54,43,33};
int n=sizeof(arr)/sizeof(int);
void main(){
    int i,j;
    for(i=0;i<n;i++){
        for(j=0;j<n-i-1;j++)
        {
            if(arr[j]<arr[j+1]){
                int temp = arr[j+1];
                arr[j+1]=arr[j];
                arr[j]=temp;
            }
        }
    }
    for(i=0;i<n;i++){
        printf("%d ",arr[i]);
    }
}