#include<stdio.h>
int input[]={18,11,282,293,48,39,3,55,32,1,2,33};
int size=  sizeof(input)/4;
void heapify(int n ,int i){
    int largest= i;
    int left = 2*i+1;
    int right = 2*i+2;
    if(left< n && input[largest] < input[left]) {
        largest=left;

    }
    if(right< n && input[largest] < input[right]){
        largest = right;
    }
    if(largest != i ){
        int temp = input[largest];
         input[largest] = input[i];
         input[i]= temp;
         heapify(n,largest);
    }
}

void main(){
printf("%d",size);

    int i=size/2-1;
    for(;i>=0;i--){
        heapify(size,i);
    }
  
     for(i=0;i<size;i++){
        printf("%d  ",input[i]);
    }
      i=size-1;
    printf("\n");
    for(;i>=0;i--){
        int temp = input[i];
        input[i]=input[0];
        input[0]=temp;
        heapify(i,0);
    }
    for(i=0;i<size;i++){
        printf("%d  ",input[i]);
    }
}