#include<stdio.h>
int arr[]={54,45,334,545,54546,768,657,565,434,432};
int n = sizeof(arr)/sizeof(int);
void main(){
    int i,j;
    for(i=1;i<n;i++){
        int temp=arr[i];
        for(j=i-1;j>=0 && arr[j]>temp;j--){
            arr[j+1]=arr[j];
        }
        arr[j+1]=temp;
    }
    for(i=0;i<n;i++){
        printf("%d ",arr[i]);
    }
}