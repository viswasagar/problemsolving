#include<stdio.h>
int input[]={18,11,282,293,48,39,3,55,32,1,2,33};
int size=12;
void  merge(int left,int mid,int right){
    int len1 = mid-left+1;
    int len2 = right -mid ;
    int arr1[len1];
    int arr2[len2];
    int i =0,j=0;
    int k=left;
    for(;i<len1;i++){
        arr1[i]=input[left+i];
    }
    for(i=0;i<len2;i++){
        arr2[i]=input[mid+i+1];
    }
    i=0;
    while(i<len1 && j<len2){
        if(arr1[i] >= arr2[j]){
               input[k++]=arr1[i++];
        }
        else{
            input[k++]=arr2[j++];
        }
        }
   
    while(i<len1){
        input[k++]=arr1[i++];

    }
    while(j<len2){
        input[k++]=arr2[j++];
    }
}
void sort(int left,int right){
    if(left < right){
    int mid= (left+right)/2;


    sort(left,mid);
    sort(mid+1,right);
    merge(left,mid,right);
}
}


void main(){
    sort(0,11);
for(int i=0;i<12;i++){
    printf("%d  ",input[i]);
}
}