#include<stdio.h>
int arr[]={32,23,44,445,56,76,56,45,76,88,99,9};
int n = 12;
void pivott(int left,int right){
    if(right-left<=0){
        return;
    }
    int pivot = arr[(left+right)/2];
    int i=left,j=right;
    while(i<=j){
        while(arr[i] > pivot){
            i++;
        }
        while(arr[j]<pivot){
            j--;
        }
        if(i<=j){
            int temp = arr[i];
            arr[i]=arr[j];
            arr[j]=temp;
            i++;
            j--;
        }
    }

    pivott(left,i-1);
    pivott(i,right);
}

void main(){
     for(int i=0;i<12;i++){
        printf("%d  ",arr[i]);
    }
     printf("fjdkfjlas\n");
    pivott(0,11);
   
    for(int i=0;i<12;i++){
        printf("%d  ",arr[i]);
    }
}