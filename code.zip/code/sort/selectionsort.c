#include<stdio.h>
int arr[]={1,43,34,65,54,434,5665,767,878,5,4,3};
int n = sizeof(arr)/sizeof(int);
void main(){
    int i,j;
    int min;
    for(i=0;i<n;i++){
        int mini=i;
        for(j=i;j<n;j++){
            if(arr[j]<arr[mini]){
                mini=j;
            }
        }
        if(mini!=i){
        arr[i]^=arr[mini];
        
        arr[mini]^=arr[i];
        arr[i]^=arr[mini];
        }
    }
    for(i=0;i<n;i++){
        printf("%d  ",arr[i]);
    }
}