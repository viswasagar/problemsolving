#include<stdio.h>
void main(){
    int mat[4][4]={{16,14,15,12},{13,11,10,9},{8,5,6,7},{1,2,3,4}};
    int count=16;
    int i,j;
    int n =4;
    i=1;
    int temp;
int flag=0;
    while(i<=count){
        j=0;
        flag=0;
        while(j<=count-1){
            if(mat[j/n][j%n] > mat[(j+1)/n][(j+1)%n])
            {
                temp=mat[j/n][j%n];
                mat[j/n][j%n]=mat[(j+1)/n][(j+1)%n];
                mat[(j+1)/n][(j+1)%n]=temp;
                flag=1;
            }
j++;       
        }
        if(flag==0){
            break;
        }
i++;
    }
    for(i=0;i<4;i++){
        for(j=0;j<4;j++){
            printf("%d ",mat[i][j]);
        }
    printf("\n");
    }
}