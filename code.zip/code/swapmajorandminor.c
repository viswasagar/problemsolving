#include<stdio.h>
void main(){
    int mat[4][4]={{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};
    int temp;
    int i =0;
    int j=0;
    int k=0;
    int f=3;
    while(i!=4 && j!=4){
        temp=mat[i][k];
       mat[i][k]= mat[j][f];
        mat[j][f]=temp;
        i++;
        k++;
        f--;
        j++;

    }
for (i=0;i<4;i++){
    for(j=0;j<4;j++){
        printf("%d ",mat[i][j]);
    }
    printf("\n");
}
}