int maxArea(int* height, int heightSize) {
    int max=0;
    int area=1;
    int flag=0;
    for(int i=0;i<=heightSize-2;i++){
       flag=1;
       int j;
        for( j=i+1;j<=heightSize-1 && height[i]>=height[j];j++){
       area=height[j]*(j-i);
         if(max < area){
            max=area;
        }
        }
        for(int k=i;k>=0;k--){
            if(height[k] >= height[j-1]){
                area=height[j-1]*(j-1-k);
                if(max <area){
                    max=area;
                }
            }
        }

        int min=height[i];
        
      for(;j<=heightSize-1;j++){
         if(height[j]<min)
         {  min=height[j];
      }
      area=min*(j-i);
      if(max<area){
        max=area;
      }
        for(int k=i;k>=0;k--){
            if(height[k] >= min){
                area=min*(j-k);
                if(max <area){
                    max=area;
                }
            }
        }

      if(height[j] >= height[i]){
        area=height[i]*(j-i);
        if(max < area){
            max=area;
        }
          for(int k=i;k>=0;k--){
            if(height[j] >= height[i]){
                area=height[i]*(j-i);
                if(max <area){
                    max=area;
                }
            }
        }


      }
      }       
    }
    
    if(!flag){
        if(height[0] <= height[1]){
            return height[0];
        }
        else{
            return height[1];
        }
    }
    return max;
}