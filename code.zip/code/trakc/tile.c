#include<stdio.h>
int grid[8][8]={{0,0,-1,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0}};
int tile=0;
void place(int r1,int c1,int r2,int c2,int r3,int c3){
    tile++;
    grid[r1][c1]=tile;
    grid[r2][c2]=tile;
    grid[r3][c3]=tile;
}
void solve(int size,int r,int c,int mr,int mc){
    if(size==2){
        tile++;
        for(int i=r;i<size;i){
            for(int j=c;c<size;j++){
                if(grid[r][c]==0){
                    grid[i][j]=tile;
                }
            }
        }
    }
int mr,mc;
for(int i=r;i<size;i++){
    for(int j=c;c<size;j++){
        if(grid[i][j]!=0){
            mr=i;
            mc=j;

        }
    }
}
    if(mr>=0 && mc>=0 && mr < size/2 && mc < size/2){
        place(size/2,size/2-1,size/2,size/2-1,size/2-1,size/2);

    }
    else if(mr < size/2 && mc > size/2-1 && mr>=0 && mc>=0 ){
place(size/2-1,size/2-1,size/2-1,size/2,size/2,size/2);
    }
    else if(mr>=size/2 && mc<=size/2-1 && mr>0 && mc >0){
place(size/2,size/2-1,size/2-1,size/2-1,size/2-1,size/2);
    }
    else{
place(size/2-1,size/2-1,size/2-1,size/2,size/2,size/2-1);
    }
    solve(n/2,);
    solve(n/2,);
    solve(n/2,);
    solve(n/2,);
}


void main(){
    solve(8,0,0,0,2);
}