#include<stdio.h>
void main(){
    int mat[4][4]={{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};
    int i=0,j;
    while(i<4){
        j=i;
        while(j<4){
            int temp;
            temp=mat[i][j];
            mat[i][j]=mat[j][i];
            mat[j][i]=temp;
            j++;
        }
        i++;
    }

    for(i=0;i<4;i++){
        for(j=0;j<4;j++){
    printf("%d ",mat[i][j]);
        }
        printf("\n");
    }

}